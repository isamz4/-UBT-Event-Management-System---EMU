# Review screenshots

Current captures are in [v15/](v15/) and show approved public partner names without private contact values. Obsolete V14 prototype captures were removed from this branch to avoid distributing fictional sponsor/contact records; they remain available on the preserved develop-v14 branch.
