# V14 Phase 1 — overall implementation status

The explicitly requested Phase 1 work is implemented on the local `develop-v14` branch. This is a polished development/demo build; it does not establish production readiness. No main merge, remote push, or deployment has been performed.

| Requested area                      | Status and evidence                                                                                                                                                                                                                                                                                                                                 |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Existing bug fixes                  | Implemented: continuous search focus/caret, idempotent request conversion and saved linkage, dynamic Riyadh dates, calendar month/year navigation, Viewer event details, fail-closed roles, validation, safe local-storage recovery, KPI destinations, Both-campus inclusion, deletion confirmation.                                                |
| All nine pages                      | Shared V14 navigation, typography, spacing, icons, focus treatments and brand assets are applied throughout. Relevant tables, forms, empty states and responsive layouts are refined. Dashboard and linked-partner selector receive the largest additions. Users & Access remains the existing role-model demonstration, not a real user directory. |
| Arabic / RTL                        | Arabic is the first-visit default. Language choice persists. UI labels, enum options, statuses and generated messages are localized; document direction, sidebar, forms and layouts support RTL. Official content and user notes retain their original language.                                                                                    |
| English / LTR                       | English UI and correct LTR direction are implemented throughout the same views and dialogs. Missing optional translations fall back to available content.                                                                                                                                                                                           |
| Linked Partners                     | Responsive selection cards, correctly sized checkboxes, bilingual search, selection count, wrapping and persistent selection during filtering. All 21 partner IDs retained; public records use sanitized fixtures, and the approved import is stored privately.                                                                                                                                                                |
| Dashboard / forms / tables / mobile | Refined KPIs, local-record executive summary, actionable attention panel, quick actions, readiness chart and month-chart drilldown; labelled validated forms and accessible dialogs; desktop tables and mobile record cards; mobile calendar agenda and navigable sidebar.                                                                          |
| Official branding                   | Original approved navy and white EMU PNGs used according to surface contrast, including print layouts. Original bytes/proportions/transparency preserved. UBT remains unchanged.                                                                                                                                                                    |

## Automated verification

Final run: `CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -v` — **25 passed, zero failed, zero skipped**.

Coverage includes:

- Nine pages × two languages × five widths (1440, 1024, 768, 390, 320): 90 page/layout combinations.
- Six dialog types × two languages × five widths: 60 label/overflow dialog checks.
- Actual navigation-button clicks for all nine pages in both languages.
- Search typing/caret preservation, empty results, bilingual linked-partner filtering, selection preservation and record persistence.
- Request validation, creation, pending-conversion rejection, approved conversion, saved source linkage and duplicate prevention after reload.
- Event validation and confirmed deletion; task creation, reference consistency, partner validation, follow-up history and approval updates.
- Unknown/missing roles, Viewer event details and revoked edit permission.
- Calendar year boundaries and current-day highlighting, campus filters, KPIs and interactive chart filtering.
- Focus trapping/restoration, Escape, mobile navigation, and responsive no-overflow checks.
- Corrupted storage preservation/recovery, quota failure reporting, stale-tab protection, localized fallbacks, CSV output and both entry points.
- EMU asset SHA-256 identity, image decoding, correct variants, rendered aspect ratios and print visibility.
- 32 sanitized review screenshots, including event request forms on desktop and mobile.

JavaScript syntax and Git whitespace checks also passed. Browser verification uses Chromium on Linux with emulated viewport sizes, not physical devices. Screenshot capture is functional evidence, not automated visual-baseline comparison.

## Remaining issues and limits

- Real authentication/SSO, server-enforced permissions, a shared database, immutable audit logs and backups are outside this phase. The login and roles remain a browser demonstration.
- No backend notifications, resource-conflict engine, budget/registration/attendance lifecycle or routed institutional approval system was introduced.
- Browser storage is not a multi-user database. Stale writes are blocked, but unsaved session data is not automatically merged. Retry reading discards temporary edits.
- Old V10 request conversions have no reliable provenance; the application cannot retrospectively infer which events originated from them. V14 conversions store the link.
- Closing forms, switching language or moving into follow-up dialogs can discard unsaved edits; save first. A general dirty-form confirmation is not part of the explicitly requested fixes.
- Viewer event details are available; request/task/partner editors remain limited to Staff/Admin.
- Native date-picker chrome follows browser/OS locale; application dates and labels are localized. Official names and user-written notes are preserved rather than translated automatically.
- Safari, Firefox, physical-device testing and a formal screen-reader/conformance audit remain unverified.

See [screenshots](SCREENSHOTS.md), [implementation details](V14_PHASE1.md), and [safe local preview instructions](PREVIEW.md).

## Partner database follow-up

The approved private import and the independent participation/relationship/sponsorship fields are complete. See [the current partner model and privacy boundary](PARTNER_DATA_MODEL.md). Dedicated contact people and notes history are supported. Prior public contact details have been replaced with fictional demo fixtures and screenshots; pre-existing Git history has not been rewritten.
