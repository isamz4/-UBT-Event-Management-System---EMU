# Approved EMU branding update — V14

The user-provided ZIP was downloaded and inspected successfully before any project changes. Its two original PNG entries were copied byte for byte into `assets/branding/`; macOS metadata entries were ignored. Both files retain their original 2249 × 1140 dimensions, RGBA transparency, filename and image bytes. File hashes are recorded in the asset README and asserted in regression tests.

## Placement

- Login on white: navy EMU logo alongside the unchanged UBT logo.
- Shared header on all nine pages: navy EMU logo on white, including narrow mobile widths.
- Sidebar and mobile navigation: white EMU logo on the navy surface. The previous white identity panel was changed to a navy panel to provide the correct contrast.
- Dashboard hero: white EMU logo on navy.
- Reports: navy EMU logo in a light identity strip.
- All printable page layouts: a dedicated white print header with the navy EMU logo and the unchanged UBT logo. White-on-dark screen branding is hidden for printing.
- Historical nested entry point: uses the same shared assets through URLs resolved from `app.js`.

All sizing preserves the full original canvas and aspect ratio. No filter, crop, mask, color manipulation, stretch, or optimization is applied. The old root and nested EMU logo files were removed. UBT images, seed data, and workflows were not changed.

## Validation

The browser suite covers both languages, all five requested widths, all nine pages, image decoding, 2249:1140 rendered ratios, correct surface variants, mobile navigation, print styles, and both entry points. The existing functional regressions remain in the same run. Review images include refreshed dashboards, forms and directories, plus login, mobile navigation, reports and print views.

**Validation result:** 20 browser tests passed with no failures or skips, followed by a successful targeted refresh of all 26 review screenshots. ZIP-to-asset byte comparisons, UBT/seed integrity checks, JavaScript syntax and Git whitespace checks passed. No remote push, merge, or deployment is part of this update.
