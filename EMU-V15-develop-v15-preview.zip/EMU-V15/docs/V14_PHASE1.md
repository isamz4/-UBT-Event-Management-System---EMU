# V14 Phase 1 implementation and review

**Branding follow-up:** the subsequently approved EMU originals now supersede the V10 EMU logos. See [the branding update](EMU_BRANDING.md) for asset integrity, placement and current verification. UBT remains unchanged.

## Scope

Implemented on `develop-v14` from the supplied V10 checkout. The visual foundation remains V10: official UBT/EMU logos, navy/burgundy/white, sidebar navigation, dashboard KPIs, cards and existing workflows. No page or original sponsor record was removed. At the Phase 1 baseline the original logos were retained; the later approved branding update replaces only the EMU logos. No GitHub Pages deployment, main merge, production API, or AI integration is included.

## Modified files

| File                                       | Purpose                                                                                    |
| ------------------------------------------ | ------------------------------------------------------------------------------------------ |
| `index.html`                               | Arabic-first accessible application entry point                                            |
| `UBT_EMU_V10_Roles_Branding/index.html`    | Historical entry point sharing the root implementation                                     |
| `data.js`                                  | Original V10 seed data extracted without changes                                           |
| `app.js`                                   | Existing workflows plus V14 validation, localization, navigation, storage and dialog fixes |
| `styles.css`                               | Existing brand styling plus responsive and visual refinements                              |
| `tests/test_v14.py`                        | Browser regressions, responsive matrix and screenshot capture                              |
| `requirements-dev.txt`                     | Pinned browser-test dependency; not needed by the application                              |
| `.gitignore`                               | Ignore Python test caches and optional virtual environment                                 |
| `README_V14.md`                            | Local run, test and recovery instructions                                                  |
| `docs/SCREENSHOTS.md`, `screenshots/*.png` | Bilingual desktop/mobile review gallery                                                    |

## Core fixes

- Search rerenders preserve input focus, text and caret selection. Arabic search normalizes diacritics and common Alef variants.
- Request conversion records `sourceRequestId` and `eventId`, reopens the existing event instead of duplicating it, and persists the link across reloads. Request IDs cannot be edited after creation; duplicate IDs are rejected.
- Current-day, current-month, upcoming, overdue and weekly calculations use the current Riyadh date. Month controls cross year boundaries and include a Today reset.
- Viewer users can open event details and search linked partners, while editing and deletion are unavailable. Missing/unknown roles fail closed; action-time checks also handle permission changes after a form opens.
- Event forms validate titles, scheduling and readiness bounds. Request, task, partner and follow-up forms validate required content and email/date constraints. Errors are localized and focusable.
- Event deletion requires confirmation, deletes dependent tasks/approvals and clears linked request pointers.
- Campus filters include Both records for either campus. Dashboard task/approval KPIs open the appropriate tab and filter; partner/report KPIs lead to relevant records.
- Safe startup handles invalid JSON and invalid nested record shapes without overwriting the original. Quota/write failures are visible, with explicit recovery actions. Stale-tab saves cannot silently overwrite newer records.
- Task-to-event references are kept consistent after task saves. CSV output keeps Unicode, uses the current language and protects spreadsheet formula prefixes. Export explicitly states that all contacts are included.

## Partner selection

Linked Partners uses responsive selection cards with correctly sized native checkboxes and large label targets. Bilingual name/category/activity search filters cards without rebuilding or losing selected values. The selected count is announced. Names use automatic direction and wrapping; spacing is logical in RTL/LTR. Existing partner database records are unchanged.

## Bilingual behavior

Arabic is the first-visit default. User language preference persists. Navigation, role labels, statuses, enum dropdowns, validation, calendar headings, contact channels, recovery notices and generated log prefixes are localized. Dates use `Intl.DateTimeFormat` with a Gregorian calendar. Missing optional translations fall back to available content. Official event and partner names are preserved exactly; user-entered notes are not translated.

## Visual refinement

- Consistent inline SVG navigation and KPI icons, active indicators, restrained transitions and keyboard focus rings.
- Refined dashboard hero, event timeline, readiness meter, actionable attention cards and quick actions.
- EMU Intelligence provides a deterministic operational summary from local records. It does not call an AI service.
- Readiness chart links to reporting; monthly report bars support pointer/keyboard drill-down into a filtered event list.
- Better field alignment, section headings, sticky dialog headers/actions and bounded dialog scrolling.
- Mobile tables become labelled record cards; the mobile calendar becomes a touch-friendly month agenda instead of tiny dots.
- Sidebar backdrop, Escape handling and keyboard containment on mobile; reduced-motion preference honored.
- Dialog semantics, associated field labels, focus containment/restoration, inert background and live feedback.

## Validation

The automated suite exercises:

- All nine pages × Arabic/English × 1440, 1024, 768, 390 and 320px: **90 page/viewport/language combinations**.
- Six existing dialog types across those language/viewport combinations: **60 dialog checks**, including associated labels and horizontal overflow.
- Continuous typing, zero-result states, selection preservation, event persistence/deletion, form validation, task/approval/follow-up flows, request conversion after reload, role restrictions and permission revocation.
- Calendar navigation across December/January, current-date highlighting, campus inclusion, KPI filters, chart drill-down/reset, keyboard modal behavior, mobile navigation, corrupt-storage recovery, quota failure, stale-tab conflicts, bilingual fallbacks, Unicode CSV and both entry points.
- Desktop/mobile review screenshots in both languages.

Execution: Python 3.12, Playwright 1.62.0, system Chromium 154 on Linux. The screenshot suite uses real seed dates; counts reflect the date of capture. The date-boundary test fixes its own clock independently.

**Current validation: 25 tests passed, zero failures and zero skips**, including the approved-branding checks, real navigation-button coverage, request-form workflow checks, and capture of 32 sanitized review screenshots (17 October 2026). `node --check app.js` and Git whitespace checks passed. Partner IDs and event relationships are preserved; public partner details are now fictional and the approved import is private. UBT images remain unchanged; approved EMU originals match the supplied ZIP byte for byte. Screenshots are review evidence, not pixel-diff assertions or proof of physical-device/browser compatibility. See [the overall status](V14_STATUS.md) and [preview instructions](PREVIEW.md).

## Remaining limitations

- Login and roles remain a local demonstration. Client-side permissions cannot protect institutional data; SSO, authenticated server authorization, a shared database, immutable audit logging and backups remain production prerequisites.
- No full multi-user/concurrent editing system. Stale persisted records are detected, but changes in temporary recovery sessions are not merged. Retry reading intentionally discards unsaved session edits.
- Historical V10 request conversions without provenance cannot be matched safely to events. Duplicate prevention applies to conversions made with V14 links.
- Viewer event details are read-only; the older task, request and partner editors remain limited to Staff/Admin.
- No backend notification delivery, venue/resource conflict engine, approval routing, budget, attendance, registration or post-event evaluation workflow was added.
- Official titles and user-authored notes retain their source language. Native date-picker controls follow the browser/OS locale even though application date displays and labels are localized.
- No general unsaved-changes confirmation. Save edits before switching language, closing a form or opening follow-up dialogs.
- Tested in Chromium with emulated viewport sizes. Safari, Firefox, physical devices and a formal screen-reader audit remain outstanding.

## Review boundary

Review the local development branch and screenshots. Publication, pushing to a remote, deployment and merging are separate actions and were not performed.
