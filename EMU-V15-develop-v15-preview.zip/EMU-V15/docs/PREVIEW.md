# Preview develop-v14 without affecting the live website

The public preview contains synthetic partner contacts only. The real imported development dataset is deliberately excluded; see [the data boundary](PARTNER_DATA_MODEL.md).

The development branch exists in this workspace and has not been pushed. No GitHub Pages settings, deployment workflows, or main branch were changed. A local preview does not contact the live site and uses separate browser storage.

## Downloadable source preview

Use the supplied `EMU-V14-develop-v14-preview.zip`, exported from the committed `develop-v14` branch. Extract it on your own computer. Keep its `EMU-V14-preview` folder intact, including `assets`, `data.js`, `app.js`, and `styles.css`.

In a terminal, change into that extracted folder and run:

```sh
cd "/path/to/EMU-V14-preview"
python3 -m http.server 8014 --bind 127.0.0.1
```

On Windows, `py -m http.server 8014 --bind 127.0.0.1` is an alternative if `python3` is unavailable.

In a browser on the same computer, enter `http://127.0.0.1:8014`. This is a local address, not a published preview link. Enter a valid email-format address and choose a demo role. Arabic is the first-visit default; use English in the header to switch. Stop the server with Ctrl+C.

No dependency installation, build, login service, or AI key is needed. Use a private browser window for a fresh demonstration without older local records or language preferences.

## From the existing development checkout

If this workspace is available in your own development environment:

```sh
git switch develop-v14
python3 -m http.server 8014 --bind 127.0.0.1
```

A normal clone from GitHub will not have the unpushed local branch. Use the downloadable preview rather than expecting a remote branch or GitHub Pages URL to exist.
