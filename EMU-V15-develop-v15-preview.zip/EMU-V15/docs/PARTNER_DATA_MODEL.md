# V14 partner model and private import boundary

## Independent fields

| Field                    | Meaning                                                                                                   |
| ------------------------ | --------------------------------------------------------------------------------------------------------- |
| `previousParticipation`  | Original source participation statement; never used to infer current status                               |
| `relationshipStatus`     | Explicit `Active`, `Potential`, `Inactive`, `On Hold`, or `null` when unspecified                         |
| `sponsorshipStatus`      | Explicit `Not Contacted`, `Contacted`, `Negotiating`, `Confirmed`, `Declined`, or `null` when unspecified |
| `contactPerson`          | Dedicated contact-person value, separate from general notes                                               |
| `notes` / `notesHistory` | Current notes with historical text retained before edits                                                  |
| `history`                | Existing follow-up history, preserved independently                                                       |

Legacy `status` is retained in private historical records when already present, but the V14 interface does not read it as either of the new statuses. Existing browser records without explicit new fields display Not specified. Adding a follow-up does not change relationship or sponsorship status. Imported participation values are not automatically translated or treated as evidence of a current agreement.

## Approved private import outcome

The approved 20-row source CSV was applied to a development JSON dataset **outside this repository and the application HTTP root**. The source file and before-import backup are likewise outside tracked/public files.

- 20 matched records updated; zero new records; total remains 21.
- IDs and official CSV names preserved; unmatched ID 12 retained unchanged.
- IDs 3 and 12 remain distinct despite a shared phone number.
- Existing event/task/approval records, follow-up histories and all five event-partner references are unchanged.
- All 19 already-valid international CSV phone values preserved exactly.
- 20 original participation statements retained; 12 dedicated contact-person fields populated.
- Current relationship/sponsorship status left unspecified where no independent supporting data exists. No inferred status updates.
- Blank optional values do not erase prior contact data.
- Existing notes preserved; distinct incoming notes appended with history. Old English activity translations are archived privately when the Arabic source changes; the interface falls back to the approved Arabic source until an approved English translation exists.
- Validation has zero errors. A second import of the same file makes zero changes.

## Public demo sanitization

Public partner fixtures now use fictional bilingual organization/contact names, blank phones, reserved `example.invalid` email addresses and clearly labelled demonstration notes. Public status values are synthetic UI examples, not conclusions drawn from the private CSV. Partner IDs and event relationships remain stable.

All current review screenshots are regenerated from these synthetic fixtures. The local preview archive is regenerated from the sanitized development branch. Approved EMU/UBT assets are unchanged.

The uploaded CSV, contact details, private dataset, backup, import scripts and private UI checks are not included in the commit or preview archive. Public code only contains the generic schema and synthetic examples. Do not copy a private dataset into the public checkout, even as an ignored file: a static HTTP server can still expose ignored files.

**History limitation:** sanitizing the current checkout does not remove contact details already present in older repository commits or copies previously downloaded. Git history has not been rewritten, and nothing has been pushed or deployed.

## Verification

- 25 public browser tests passed, including independent status handling, no legacy inference, dedicated contact editing, historical-note preservation, synthetic fixtures and the existing bilingual/responsive regressions.
- Private dataset UI validation covers Arabic/English at widths 1440, 1024, 768, 390 and 320, without taking private screenshots or changing the saved private dataset.
- Original private names, contact values, IDs, histories, notes and relationships are checked directly against the original CSV and before-import backup, with only redacted results logged.
