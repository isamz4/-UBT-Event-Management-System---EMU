# V14 review screenshots

Captured from the local development build with sanitized, fictional partner fixtures. No imported private contacts appear in these screenshots. Official names remain in their source language. Mobile images are 390 × 844 viewport frames; desktop dashboards and partner directories include the full page.

| Interface                    | Arabic RTL                                                          | English LTR                                                          |
| ---------------------------- | ------------------------------------------------------------------- | -------------------------------------------------------------------- |
| Login                        | [Arabic login](../screenshots/login-ar.png)                         | [English login](../screenshots/login-en.png)                         |
| Reports                      | [Arabic reports](../screenshots/reports-ar.png)                     | [English reports](../screenshots/reports-en.png)                     |
| Print layout                 | [Arabic print](../screenshots/print-report-ar.png)                  | [English print](../screenshots/print-report-en.png)                  |
| Mobile navigation            | [Arabic navigation](../screenshots/mobile-navigation-ar.png)        | [English navigation](../screenshots/mobile-navigation-en.png)        |
| Dashboard                    | [Arabic dashboard](../screenshots/dashboard-ar.png)                 | [English dashboard](../screenshots/dashboard-en.png)                 |
| Event form                   | [Arabic event form](../screenshots/event-form-ar.png)               | [English event form](../screenshots/event-form-en.png)               |
| Linked Partners cards        | [Arabic selector](../screenshots/linked-partners-ar.png)            | [English selector](../screenshots/linked-partners-en.png)            |
| Sponsors & Partners          | [Arabic directory](../screenshots/partners-ar.png)                  | [English directory](../screenshots/partners-en.png)                  |
| Mobile dashboard             | [Arabic mobile dashboard](../screenshots/mobile-dashboard-ar.png)   | [English mobile dashboard](../screenshots/mobile-dashboard-en.png)   |
| Mobile events                | [Arabic event cards](../screenshots/mobile-events-ar.png)           | [English event cards](../screenshots/mobile-events-en.png)           |
| Mobile calendar              | [Arabic agenda](../screenshots/mobile-calendar-ar.png)              | [English agenda](../screenshots/mobile-calendar-en.png)              |
| Mobile sponsors              | [Arabic sponsor cards](../screenshots/mobile-partners-ar.png)       | [English sponsor cards](../screenshots/mobile-partners-en.png)       |
| Mobile event form            | [Arabic partner selector](../screenshots/mobile-event-form-ar.png)  | [English partner selector](../screenshots/mobile-event-form-en.png)  |
| Event request form           | [Arabic request](../screenshots/event-request-ar.png)               | [English request](../screenshots/event-request-en.png)               |
| Mobile event request         | [Arabic mobile request](../screenshots/mobile-event-request-ar.png) | [English mobile request](../screenshots/mobile-event-request-en.png) |
| Partner profile and statuses | [Arabic profile](../screenshots/partner-profile-ar.png)             | [English profile](../screenshots/partner-profile-en.png)             |

Regenerate: `CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -v`.
