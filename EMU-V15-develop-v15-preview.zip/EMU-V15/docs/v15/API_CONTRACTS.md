# Expected API contracts — Applications Department

No API server is implemented or contacted by this edition. `E15.api` exposes promise-based mock interfaces; current workflow controllers call centralized `E15` services. Replace those service operations with asynchronous API adapters, await transactions/decisions before repainting, and retain the same field/error contracts. This is an integration starting point, not a claim of zero-change backend connectivity.

## Transport and conventions

- Base path proposal: `/api/v1`. HTTPS, authenticated SSO session, CSRF protection where applicable.
- JSON UTF-8. Dates `YYYY-MM-DD`; event-local times `HH:mm`; institution timezone `Asia/Riyadh`. Audit times are ISO UTC.
- IDs are server-owned, references immutable. Preserve legacy request string IDs or supply migration mappings. Do not use phone/email as partner primary keys.
- Responses: `{ data, meta?: { version, page, total } }`. Errors: `{ error: { code, message, fields?, conflicts? } }`.
- Expected error codes: `VALIDATION_FAILED` (422), `FORBIDDEN` (403), `CONFLICT`/`STALE_VERSION` (409), `NOT_FOUND` (404), `WINDOW_CLOSED` (409), `CAPACITY_REACHED` (409).
- Version/ETag and `If-Match` for mutations. Idempotency key for submission, approval/materialization, registration, check-in and imports.
- Server revalidates every field, owner, role, department, state transition, file and relationship. Local browser role controls are not authorization.

## Endpoints

| Method / route | Request / response semantics |
| --- | --- |
| GET `/session` | Authenticated user, roles, department assignments and effective permissions |
| GET/POST `/requests` | List only visible requests; create draft from fourteen-section `details` |
| GET/PATCH `/requests/{id}` | Versioned draft edit; reference always immutable; owner changes require approved delegation |
| POST `/requests/{id}/submit` | Validate full details/acknowledgment, issue or preserve atomic reference, state Submitted |
| POST `/requests/{id}/decisions` | `{decision: Under Review|Approved|Rejected, reason}`; approval returns stable `eventId` and creates linked operational records once |
| GET/PATCH `/events/{id}` | Central record; reject direct edits to approved critical fields |
| POST `/events/{id}/transition` | `{nextStage, reason?}` with readiness and report closure gates |
| POST `/events/{id}/publication/requests` | Separate publication request; event approval prerequisite; state Pending, never automatically published |
| POST `/events/{id}/publication/decisions` | Explicit Approved/Rejected decision + reason; authorized publication reviewer; approval also requires event and Marketing prerequisites |
| POST `/events/{id}/publication/withdraw` | Withdraw pending/approved publication; clear public visibility; append audit history |
| GET/POST/PATCH/DELETE `/tasks[/{id}]` | Event-linked tasks, ownership, priority, deadlines, attachments |
| GET/POST `/approvals` | Request department review; assigned department and version |
| POST `/approvals/{id}/decisions` | `{status: Approved|Declined|Pending, reason}`; append immutable decision history |
| GET/POST/PATCH/DELETE `/reservations[/{id}]` | Atomic overlap detection including setup/breakdown; venue capacity/equipment validation; confirmation requires approvals |
| GET/POST `/events/{id}/registrations` | Window/capacity/identity checks; unique event + institutional identity |
| POST `/registrations/{id}/check-in` | Idempotent unique check-in with authoritative identity, server clock and event window |
| GET/POST/PATCH/DELETE `/volunteers[/{id}]` | Assignments, shifts, recorded hours; separate approved-hours authority |
| GET/POST/PATCH `/partners[/{id}]` | Independent participation/relationship/sponsorship/contact-person fields; history/notes preserved |
| POST `/partners/import-preview` | File checksum + header/schema validation; exact/approved ID matches; no phone merging; return versioned preview token |
| POST `/partners/import-apply` | Confirm preview token and current dataset version; transactional update; retained unmatched IDs; audit |
| GET/POST `/changes` | Store immutable old/proposed values, reason and impact |
| POST `/changes/{id}/decisions` | Apply approved changes only after freshness, authorization and venue conflict checks |
| GET/POST/PATCH `/operations[/{id}]` | Checklist/incidents, severity, responsible person, explicit resolution |
| GET/POST/PATCH `/designs[/{id}]` | Content/deadlines/screens/files and publication gate |
| GET/POST/PATCH `/expenses[/{id}]` | Budget/purchase states; Finance approval and actual ledger linkage |
| GET/PUT `/events/{id}/report` | One report per event; linked metrics authoritative; Draft/Completed; narrative/photos |
| GET `/insights?period=&year=&quarter=&month=` | Aggregated scoped metrics, department performance and compliance |
| GET/POST/PATCH `/users[/{id}]` | Provisioning metadata from approved identity source, no frontend passwords |
| GET `/audit?actor=&entity=&from=&to=&q=` | Immutable paginated server audit; redact restricted guest data by permission |
| GET/PUT `/settings` | Versioned institution-approved configuration; proposed policy labels retained until ratified |
| POST `/files` | Multipart file upload, scanning, MIME/extension/size policy, ownership; return id/name/type/size |
| GET `/files/{id}` | Authorized streaming or short-lived download; never public URLs for restricted material |
| GET `/exports/{type}` | Authorized CSV/XLSX/PDF production exports with auditing and formula-safe CSV |

## Example request decision

```json
{
  "decision": "Approved",
  "reason": "Required review completed",
  "version": 4
}
```

Expected response identifies one stable request/event pair:

```json
{
  "data": {
    "requestId": 1001,
    "reference": "EMU141026-001",
    "workflowStatus": "Approved",
    "eventId": 2001
  },
  "meta": { "version": 5 }
}
```

The dates/reference above are schema examples, not an assertion of a real approved university event.

## Integration-critical invariants

- First successful submission issues `EMUDDMMYY-NNN`, with DDMMYY derived from the event date and NNN the three-digit per-date sequence. No manual reference input, draft allocation or client-generated production authority. For event dates 2026-10-14 and 2026-10-15: `EMU141026-001`, `EMU141026-002`, `EMU151026-001`.
- Enforce a unique reference constraint across all requests, atomic per-date counter allocation and idempotent submission in the backend/database. Requests and their linked events share one reference; the event copy is not a separate allocation. Preserve the original reference after rejection/resubmission or an approved event-date change. Reject exhausted three-digit sequences at 999; never wrap or silently widen the format.
- Approve/materialize, reservation confirmation and approved-change application are server transactions.
- An event date/time change updates dependent reservations, invalidates affected confirmation and re-evaluates registration/check-in windows.
- Shared phone numbers never imply shared identity. Preserve partner IDs, original CSV participation statements, notes and histories.
- Current relationship/sponsorship statuses require independent evidence, not a previous-participation label.
- Production QR links use the configured public frontend origin; payloads should identify the event without exposing attendee PII.
- Department approval, Marketing publication and Finance purchasing authority must be mapped to actual institutional claims.
- File bytes are not in JSON backups; provide durable file storage and authorized download APIs.

Publication decisions must be independent from event approval and must bind to a version of approved event details. A critical approved event change invalidates publication approval/pending review and clears visibility in the same server transaction. Never expose a public calendar record solely because the event or Marketing department approved it.

Role/delegation endpoints and server-side security invariants are specified in RBAC_SECURITY_HANDOFF.md. Client-side role/identity fields and decision-authority labels must never be trusted as production authorization.

## Published calendar and anonymous availability

The local promise facade now includes `E15.api.publishedCalendar()` and `E15.api.checkAvailability(query)`. Production equivalents should be scoped `GET /calendar/published` and read-only `POST /venues/availability`. The former must return only the explicit public field allowlist after both approvals; the latter returns `{status, blocks:[{start,end,confirmed}]}` without source IDs, titles, owners or notes. `start/end` are epoch milliseconds. Neither endpoint authorizes operational access or creates a booking. Reservation confirmation must recheck conflicts atomically at the backend. An operational endpoint requires Director/authorized venue staff permissions. See [calendar specification](UNIVERSITY_CALENDAR.md).
