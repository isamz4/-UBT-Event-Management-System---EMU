# University calendar and availability update

Built on `eaa4608`, on `develop-v15` only. No merge, push or deployment.

## Published university calendar

Every active authenticated demo role, including System Administrator and Supporting Department, can open University Events Calendar from navigation. A row must satisfy both `E15.isApproved(event)` and explicit `calendarPublication.status === 'Approved'` with `published === true`. Event approval alone never publishes it. Historic events remain visible in list/year filters. Month, week and list views support bilingual search, campus (including Both), venue, category and date-range filters. Month/week navigation is local to the calendar.

Details and CSV/JSON exports use an explicit public projection: event ID and immutable reference, official bilingual titles, date/time, campus, venue, organizer, category, audience, and explicitly publication-approved description/image/registration URL. They never serialize raw event records, requests, budgets, comments, operational notes, partner contacts or publication decision history. HTTPS public URLs and approved local asset paths are permitted; executable URLs are rejected. Images and descriptions are optional and approved through the separate publication decision form. Existing publication gates, Marketing prerequisites, Director authority, staff delegation, expiration, revocation and audit logging remain in place.

Existing seeded scenarios are deliberately **not automatically published**. In a clean preview, the calendar can be empty until a Director publishes an approved event. Screenshots use clearly synthetic test events approved through the existing local workflow; they are not records added to the distributed seed.

## Requester landing

Authorized Event Requesters land on the calendar after login, reload or Role Preview. Other roles retain their prior landing pages. The welcome section opens the existing 14-step request wizard or standalone availability checker. Upcoming cards use the same published projection. My Event Requests includes only requests owned by the current identity. QR registration routes retain their existing landing behavior.

## Operational view

Director and EMU Staff with the existing venue/reservation operational permission can open Operational calendar. It shows events and publication status, submitted/under-review requests, active tentative/confirmed venue reservations, setup/event/breakdown intervals and reservation conflicts. Requesters, supporting departments, management viewers and technical administrators cannot open it through either navigation or direct rendering. Disabling a staff venue permission removes access. This does not grant staff publication approval; that remains a separate explicit delegation.

## Availability

The standalone checker is available to requesters, Director and authorized venue-operating EMU Staff. It is also accessible from event details/venues steps of the wizard, with a return action that preserves the current draft. The wizard can check its selected venues using entered event fields. Tentative conflicts warn but allow submission for review. Confirmed conflicts block submission until the time or venue changes. Submitting never confirms a booking.

The shared interval engine compares only the same venue, using setup start and breakdown end when present. Touching endpoints do not overlap. Cancelled/rejected reservations and drafts/rejected requests do not block availability. Submitted/under-review requests and active non-confirmed reservations are tentative; confirmed reservations are unavailable. Matching request IDs are excluded when editing the same draft. The public result contains only status plus anonymous start/end timestamps and confirmed flags. It contains no reservation IDs, event titles, names, notes or requester identities. These checks never create or confirm reservations.

The standalone checker accepts an end date and handles existing multi-day reservation data when an end date is present. The existing request wizard and reservation editor retain their single-day date model; expanding those workflows to multi-day editing is separate work. Venue timestamps are interpreted in Asia/Riyadh (UTC+03:00).

## Prototype boundaries

All identities, authorization and publication decisions are frontend simulations. Browser data is not a shared university database, and availability is neither real-time nor synchronized across devices. Client-side code cannot enforce production confidentiality against someone inspecting browser storage. University SSO, server-side scoped calendar/availability endpoints, database locking for reservations, approved public media hosting and authoritative publication records remain backend integration requirements. The API facade adds `publishedCalendar()` and `checkAvailability(query)` as local demonstration endpoints. No network service or production route was deployed.

The approved 20-record public sponsor catalog, reserved ID 12, local private overlays and unchanged official logos are preserved. Private CSVs and contact datasets remain outside source, served assets, screenshots and the preview ZIP. See [public/private mapping](PUBLIC_PARTNERS.md) for the previously reported Git-history exposure; this update does not rewrite history.

## Review screenshots

- [Requester landing — Arabic](../../screenshots/v15-calendar/requester-landing-ar.png)
- [Requester landing — English](../../screenshots/v15-calendar/requester-landing-en.png)
- [Requester mobile — Arabic](../../screenshots/v15-calendar/mobile-requester-ar.png)
- [Requester mobile — English](../../screenshots/v15-calendar/mobile-requester-en.png)
- [Published calendar — Arabic](../../screenshots/v15-calendar/published-calendar-ar.png)
- [Published calendar — English](../../screenshots/v15-calendar/published-calendar-en.png)
- [Operational calendar](../../screenshots/v15-calendar/operational-calendar.png)
- [Standalone availability](../../screenshots/v15-calendar/availability-en.png)
- [Wizard availability](../../screenshots/v15-calendar/wizard-availability.png)
- [Confirmed conflict](../../screenshots/v15-calendar/confirmed-conflict.png)

## Modified files and validation

- `v15/calendar.js`: public projection, calendar/landing, operational view, anonymous interval engine, existing wizard/publication integration and local API facade.
- `index.html`, `v15/bootstrap.js`: load and install the extension after existing permissions.
- `styles.css`: EMU calendar cards, responsive days/filters and accessible availability fields.
- `tests/test_university_calendar.py`: 12 new acceptance tests and 11 screenshots.
- `tests/test_v15.py`: two existing assertions updated for the mandatory separate publication gate, retaining reference and legacy-conversion coverage.
- README and V15 API/permissions/features/QA/commit documentation; 54 refreshed existing screenshots.

Final full discovery: 92 tests, 67 passes, 25 retained V14-only skips, zero failures. The final focused calendar rerun also passes. JavaScript syntax, whitespace, privacy and original-logo checks pass. An extracted preview is smoke-tested before delivery. All execution uses Chromium and emulated widths, not physical devices or production services.
