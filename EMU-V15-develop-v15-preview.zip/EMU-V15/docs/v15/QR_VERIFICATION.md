# QR functionality and verification

## Implemented

Every approved event has a distinct QR payload containing its stable event ID: `http(s)://<preview-host>/<entrypoint>?register=<eventId>`. Draft/unapproved events cannot generate a registration QR. A four-module quiet zone and black-on-white modules are used. Download **PNG** for camera scanning; SVG and print options remain available.

Opening the decoded link selects the exact event's Attendance & QR page, whether the user is already signed in or signs in next. Registration requires the configured registration window and available capacity. EMU Director/Staff record check-in during its configured window. A participant registration does not increment the attended count. Duplicate normalized-email registrations and repeated check-ins are blocked; statistics and CSV derive from the same records.

## Automated image-decoding test

`test_qr_png_independently_decoded_for_every_approved_event` downloads the **actual PNG through the UI for every approved fixture event**, decodes its pixels using the independent ZXing-C++ decoder, and compares the decoded URL to the correct event route. It follows each decoded URL, configures demo windows, registers and checks in a synthetic participant using UI controls, verifies counts, blocks a second check-in and exports CSV. It also verifies that every approved event payload is unique.

This verifies actual QR images, not a mocked internal decode. No physical phone camera was available in this execution environment; physical-camera testing is a manual acceptance step, not a claimed result.

To reproduce with screenshot coverage:

```sh
python3 -m pip install playwright pillow zxing-cpp
QR_DECODER_PATH=/path/to/optional/decoder/install CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -p 'test_v15.py' -v
```

`QR_DECODER_PATH` is optional when the decoder is installed in the normal Python environment. The independent image test reports a skip if that dependency is absent; it must be installed for QR acceptance testing.

## Working phone-camera demo without deployment

1. On a trusted Wi-Fi/LAN, serve the extracted preview with `python3 -m http.server 8015 --bind 0.0.0.0`.
2. Find the computer's private LAN IP (for example `192.168.1.20`). Open **that LAN address** in the computer browser: `http://192.168.1.20:8015`. Generate the PNG from there. A QR generated at `127.0.0.1` or `localhost` points the phone to itself and will not reach the computer.
3. Use the seeded approved **EMU Frontend Demonstration**, event ID **15001**. It exists in fresh preview browsers, and its demo registration/check-in windows are set for the current Riyadh day. Other historical fixture events may have closed/missing windows; configure those explicitly for testing.
4. Scan the PNG with the phone's native camera. The equivalent direct test path is `http://<computer-LAN-IP>:8015/?register=15001`. For the unchanged seeded local event, select the active **EMU Staff** demo identity and register a synthetic name/email. An Authorized Event Requester can register only for an event published in that browser or their own approved event; arbitrary guest emails no longer grant requester identity.
5. On that **same phone browser and origin**, switch to EMU Director/Staff in Users & Access, return to Attendance and check in the registration. Confirm Registered/Checked-in counts and export CSV. The computer browser does not automatically receive the phone's records.
6. Stop the HTTP server after the demonstration. No GitHub Pages change or public deployment is involved. Network/firewall/device restrictions can block LAN access; this environment cannot supply a public hosted URL without deployment.

## Backend boundaries

QR pixels and event routing work locally. Identity/roles are simulated. A production backend is required for a stable public HTTPS URL, shared event records, SSO, authoritative attendance, concurrent duplicate protection and cross-device live statistics. A newly created local event exists only in its browser; another browser must load a matching private event backup first. Unknown event QR links show an explicit unavailable message and never silently register against another event.

Final run: **6/6 approved fixture PNGs decoded correctly**, each with a distinct event URL, successful UI registration/check-in/count updates/CSV export, and duplicate check-in rejection. The complete suite passed **38/38 tests with no skips**. Physical-camera validation remains manual.

Role clarification: attendee registration remains a demonstrated frontend workflow. The role registry prevents arbitrary employees from obtaining event-submission powers. Public attendee identity/SSO and cross-device event/publication state require the university backend.
