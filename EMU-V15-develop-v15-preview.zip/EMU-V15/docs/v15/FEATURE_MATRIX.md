## University calendar extension

Published month/week/list calendar for all roles, requester landing, guarded operational view, safe public details/exports and standalone/wizard availability are implemented locally. Production authoritative booking and shared synchronization remain pending backend integration. See [details and limitations](UNIVERSITY_CALENDAR.md).

# Public catalog update

Twenty approved public partner records now load automatically. Private contact imports remain optional and local. See [public/private mapping and historical privacy finding](PUBLIC_PARTNERS.md); this supersedes earlier references below to fictional public partner names.

# V15 feature completion matrix

**Working** means an implemented, interactive browser feature using persistent local data. **Simulated** means business authority or identity is represented locally, not connected to an institutional service. **Backend Required** identifies integration responsibilities; it does not mean that the module is a placeholder.

| Module | Working frontend | Simulated | Backend Required |
| --- | --- | --- | --- |
| Dashboard | 12 derived KPIs, event countdown/timeline, charts, calendar, priorities, recent activity, quick actions | Rule-based intelligence | Shared/live data and production analytics |
| All Events | Search/campus/status filters, chart drilldowns, central workspace, draft edit/delete | Lifecycle state in browser | Server validation, ownership, concurrency |
| Annual Calendar | 2026/2027, month/list, search/category/campus, CSV/JSON, TBD retained, detail links, independent publication request/review/history/withdrawal and change invalidation | Publication authority and public visibility are local simulations | Public feed, institutional authority and transactional approvals |
| Event Requests | 14 steps, repeating venues/workshops/booths/media/guests/certificates, files, Excel import, drafts, validation, immutable references, explicit review | Requester identity and manager decisions | Atomic reference issuance, SSO, durable request storage |
| Tasks & Approvals | Assign/owner/deadline/priority/notes/files, approval reasons/history, overdue/readiness | Role/department authority | Delegation, notifications, institutional routing |
| Venue Reservations | Calendar, capacity/equipment, multi-venue linkage, setup/breakdown conflicts, confirmation gates | Demo capacities/equipment | Authoritative resource inventory and transactional reservations |
| Attendance & QR | Real QR PNG/SVG/link, independent image-decoding test, registration/check-in windows, counts/rates/no-shows, duplicate prevention, list, CSV, QR print/download | Identity is labelled mock-verified | Reachable hosted routes, SSO identity, cross-device live check-in |
| Volunteers | Requirements, event assignments, allocation, shifts, participation, recorded/approved hours, summary/XLSX | Hours approval | University identity, supervisor authority, attendance proof |
| Sponsors & Partners | Dedicated contact person, independent participation/relationship/sponsorship, follow-ups, next contact, linked events, search/filter/edit, private baseline + CSV preview/confirmation/export | Fictional public fixture identities | Private contact store, authorization and consent |
| Change Requests | Old/proposed values, reason/impact, review/rejection, approved application, venue/date synchronization, history | Manager authority | Transactional conflicts, authorization and notifications |
| Post-Event Reports | Linked prefill, attendance/partners/workshops/booths/volunteers/hours/purchased costs, achievements/challenges/recommendations/satisfaction/photos, English narrative, print/PDF-ready, closure gate | Rule-composed English narrative; not generative AI | Report retention, approval signatures, centralized files |
| Executive Insights | Month/quarter/year, events/attendance/partners/volunteers/budget/satisfaction/department metrics, charts, Excel, print | Local dataset scope | Authoritative reporting and warehouse queries |
| Operations & Alerts | 10-item event checklist, incidents, severity/responsible person/resolution, readiness and alerts | Local operational status | Live integrations, escalations and notifications |
| Users & Access | Six roles, seven preview identities, Director-controlled user/requester registry, independent staff approval delegation/expiry/revocation, individual toggles, scoped routes/data and technical/business separation | Login/role switching explicitly simulated | SSO, real RBAC, provisioning and backend authorization |
| Activity Log | Actor/action/time/entity/before-after/reason, approval decisions, search | Locally editable storage is not tamper-proof | Immutable server audit and retention |
| System Settings | Departments, venues/capacities/equipment, categories, required approval departments, giveaways, regulations, local notification preferences, calendar and proposed policy values, backup/restore/reset | Policy examples remain proposed; no emails are sent | Institution-approved policy engine and centralized settings |

## Linked event workspace

Eleven real tabs share the same event ID: Overview, Original Request, Schedule & Venues, Tasks & Approvals, Guests & Partners, Volunteers, Budget, Designs & Media, Attendance, Change Requests, Post-Event Report. Approved event critical fields require a reviewed change. Closure requires completed tasks/approvals/reservations/checklists and a completed report.

## Explicit limitations

- Frontend-only local demo; it is not secure multi-user software. Browser role guards are not a security boundary.
- Approval departments are configurable parallel required approvals. A production sequential/delegated routing engine belongs to integration.
- Notification preferences control local priority visibility; email/SMS/push delivery is not connected.
- Ask EMU analyzes local rules and provides editable drafting; no connected generative AI or API key exists.
- PDF output uses the browser Print/Save PDF interface. It is not a server PDF generation service.
- Files are stored in IndexedDB, up to 5 MB each. JSON backup includes attachment metadata, not the file bytes. Excel certificate import is capped at 1 MB and 1000 names.
- Legacy calendar/request records may have incomplete original details. Unknown times and TBD dates are not invented; new requests collect the full schema.
- QR links encode the current preview origin. Scanning on a different device requires that origin to be reachable; local loopback is not a public URL.
- Chromium is tested. Safari/Firefox, physical devices and formal assistive-technology certification remain unverified.

Mandatory acceptance traceability: [all seven Director requirements](DIRECTOR_REQUIREMENTS.md), including explicit limitations and the publication-flag migration.

Final corrections: [private real-partner loading](PRIVATE_PARTNERS.md) and [QR test evidence / phone demo path](QR_VERIFICATION.md).

The approved role clarification supersedes earlier broad Admin/Staff permissions. [Permissions matrix](PERMISSIONS_MATRIX.md) and [complete access requirements](ROLE_ACCESS_REQUIREMENTS.md) define the current behavior.
