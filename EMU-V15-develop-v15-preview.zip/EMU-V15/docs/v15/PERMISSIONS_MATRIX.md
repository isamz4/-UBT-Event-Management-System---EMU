# V15 six-role permissions and delegation

Policy source: `v15/access.js` (`E15.accessPolicy`, `E15.auth`, scoped render/API helpers). Six roles and seven sanitized preview identities are provided; Delegated EMU Staff is an identity with specific grants, not a seventh role. The original approved requirements are retained in ROLE_ACCESS_REQUIREMENTS.md.

| Capability | System Administrator | EMU Director | EMU Staff | Authorized Event Requester | Supporting Department | Management Viewer |
| --- | --- | --- | --- | --- | --- | --- |
| Dashboard | Technical | Dedicated executive | Operational | Own requests | Assigned department work | Read-only executive |
| Events/workspaces | No | All | Operational | Own approved / published events | Relevant assigned events | Approved summaries |
| Private requests | No | All | Operational coordination | Own only | No | No |
| Create/submit request | No | Yes | Yes | Active + explicitly authorized registry entry | No | No |
| Event approval | No | Yes | Independently delegated only | No | No | No |
| Change approval | No | Yes | Independently delegated only | No | No | No |
| Calendar-publication approval | No | Yes | Independently delegated only | No | No | No |
| Request a change | No | Yes | Operational events | Own approved event, authorized identity | No | No |
| Department task/approval | No | Operational | Operational | No | Assigned department only | No |
| Venues/volunteers/attendance/operations | No | Manage | Manage within individual permissions | Own/published event registration | Relevant task/venue details | Summary metrics only |
| Sponsors & Partners, profiles, import/export | **Denied** | Yes | Yes unless Director disables individual permission | **Denied** | **Denied** | **Denied** |
| EMU reports | No | Prepare/manage | Prepare within permission | No | No | Completed reports explicitly shared for management |
| Executive Insights / Intelligence | No business data | Full authorized EMU data | Operational summaries | No | No | Approved/authorized summaries |
| Users & Access | Read-only technical directory and own profile | Directory, roles, authorization, activation, staff permissions, delegation | Own profile/grants | Own profile | Own profile | Own profile |
| Grant/revoke delegation | No | **Director only** | No | No | No | No |
| Business settings / full data backup | No | Yes | No | No | No | No |
| Technical configuration | Mock relative API path / integration readiness | Business settings only | No | No | No | No |
| Activity log | No EMU business log | Yes | Authorized operational log | No | No | No |

## Identity and scope rules

- An arbitrary email plus a selected role does not authorize submission. The login form must match an active identity in the local mock registry. Unknown roles/users and inactive identities fail closed.
- The Director manages requester name, email, college/department, role, active/inactive status and a separate submission-authorization toggle. Revoking submission leaves an active requester's own history readable; deactivation blocks all access.
- Supporting Department reads and updates its assigned department tasks/department decisions. A department decision does not grant event/change/publication approval authority. Required task files are scoped to readable records.
- Management report viewing additionally requires Completed + `managementAuthorized: true`; the Director controls this explicit demo sharing field. Unshared internal reports are not shown.
- Management/requester calendar views and their calendar exports show only separately approved, published records. Requesters can still view their own approved event in All Events even if unpublished.
- Non-EMU views omit partner records, linked partner names/contact fields and confidential logs. Read-only executive totals use linked aggregate rows; anonymous statistics are not attendee/contact directories. Exports and the mock list/get facade apply the same view restrictions.

## Independent delegation

Only the Director can set `reviewEvent`, `reviewChange` or `reviewPublication` for a user whose current role is EMU Staff. Each grant has enabled, grantedBy, grantedAt and optional expiresAt. The seeded delegated identity has **event-request approval only**; the other two permissions remain off.

Users & Access → staff Details / Permissions exposes three independent toggles and optional expiration dates. Apply each delegation explicitly. Separate operational toggles control tasks, venues, volunteers, attendance, partners, reports, operations, media and expenses. Revocation changes the central check immediately; expired grants fail on every subsequent check. A staff member cannot delegate or revoke for anyone, including themselves. Delegation does not add Director-only settings, user management, closure or grant-management authority.

The request decision, change reviewer and publication decision retain actor identity, role, specific permission, Director versus Delegated EMU Staff authority, and the granting Director when delegated. User changes, requester authorization, operational toggles, grants/revocations and Role Preview switches append before/after audit records.

## Demo identities

| Identity | Mock email | Role |
| --- | --- | --- |
| EMU Director | director@example.invalid | EMU Director |
| EMU Staff | staff@example.invalid | EMU Staff |
| Delegated EMU Staff | delegated@example.invalid | EMU Staff; event-request approval only |
| Authorized requester | requester@example.invalid | Authorized Event Requester |
| IT department | support@example.invalid | Supporting Department |
| Management viewer | viewer@example.invalid | Management Viewer |
| Applications | system@example.invalid | System Administrator |

The Role Preview button is always labelled as a **frontend demonstration feature**. It intentionally allows exploring these mock identities, records the switch, closes old dialogs and refreshes navigation, filters, dashboards and actions. It is not production authentication or a way to grant real authority.

Legacy `EMU Admin` user-directory rows migrate to System Administrator, **not** to Director, so technical administrators do not automatically inherit business access. The separately seeded Director identity supplies operational authority. Historical approvals retain their original recorded actors; no historical delegation is invented. Legacy local sessions using retired role names must sign in again.

## University calendar extension

All six active roles can read the separately approved published university calendar and safe public exports/details. Only the Authorized Event Requester landing changes to that calendar. The operational calendar requires Director or EMU Staff with the venue/reservation permission; supporting departments, requesters, management and technical administration are denied. Anonymous availability planning is available to requesters, Director and authorized venue staff. Publication approval still requires Director authority or an active independent `reviewPublication` delegation. No business authority is granted to System Administrator by adding calendar navigation.
