# Approved public partner catalog

The original UTF-8 CSV supplies 20 approved public records. They load automatically without import. Stable IDs are 1–11 and 13–21. ID 12 is retained as a reserved identity so existing event links remain intact; its name was not in the approved CSV and is not published. A private local backup can restore its private details.

| CSV column | Public model | Visibility |
|---|---|---|
| 1 Official partner name | name | Public, exact source text |
| 2 Category | category / catAr | Public, exact source text |
| 3 Activity | activity / actAr | Public, exact source text |
| 4 Phone | phone | Private local overlay only |
| 5 Contact person | contactPerson | Private local overlay only |
| 6 Email | email | Private local overlay only |
| 7 Previous participation | previousParticipation | Public, exact source text |
| 8 Notes | notes | Private local overlay only |

Internal histories and current relationship/sponsorship statuses are private. Previous participation never determines either current status. Missing approved English translations fall back to Arabic. Official names are never translated or invented.

`assets/data/partners-public.json` is the public allowlist catalog; `data.js` contains the compatible public seed. `state.publicPartners` and `state.partnerPrivateData` are separate models; existing forms consume a compatibility view. In a clean browser there are no private contacts. Private fields show backend-pending placeholders. Explicit local imports can populate the private overlay for an authorized local presentation; they are never written into repository assets. This browser store is not production confidentiality or authentication.

Reproduce extraction with `python3 scripts/update_public_partners.py --csv /absolute/private/path/Event_Partners_Updated_Import_UTF8.csv`. Keep the CSV outside the served checkout. The script verifies the approved file checksum and extracts only the four approved columns. Do not put private backups in the server directory.

## Verification and historical exposure

Current text assets were scanned against private phone, email, contact-person and note values from the uploaded CSV and private baseline. No prohibited matches were found. Source contains no CSV or private backup. Public seed keys are explicitly restricted; screenshots were regenerated from clean public browser contexts. Logos remain byte-identical.

An older Git revision, `71462a3a0c`, contains private values in `data.js`. A scan of 130 historical text blobs also identified sensitive values in an older `UBT_EMU_V10_Roles_Branding/index.html` blob. Removing them from the current release does not remove Git history. Separate coordinated history cleanup and any hosting/cache review are required if that revision was distributed. This task does not rewrite history or publish anything. The preview ZIP excludes `.git` and private datasets.
