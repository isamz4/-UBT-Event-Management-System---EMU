# Public catalog update

Twenty approved public partner records now load automatically. Private contact imports remain optional and local. See [public/private mapping and historical privacy finding](PUBLIC_PARTNERS.md); this supersedes earlier references below to fictional public partner names.

# Private Sponsors & Partners presentation data

The public source, screenshots and ZIP contain 21 synthetic partners only. Private contact data is never loaded automatically. No upload endpoint exists: the file inputs read files in the browser and save to this preview's localStorage. Import is restricted to localhost/private-LAN hosts, not a public GitHub Pages origin.

## Files to keep private

1. `EMU-Partners-Presentation.private.json`: separately delivered partner-only backup containing the original 21 records, including unmatched ID 12 and follow-up history. It is **not** in the source ZIP or repository.
2. Your original `Event_Partners_Updated_Import_UTF8.csv`: the approved 20-row UTF-8 CSV.

The CSV alone cannot reconstruct ID 12 or historical follow-ups. Loading it over fictional fixtures would leave a fictional unmatched record, so the approved CSV requires the private baseline first.

## Load into your own browser

1. Extract the public preview ZIP. Inside `EMU-V15-preview`, run `python3 -m http.server 8015 --bind 127.0.0.1` and open `http://127.0.0.1:8015`.
2. Use the demo **EMU Director** or **EMU Staff** role. Open **Sponsors & Partners → Import CSV**.
3. In step 1, choose the separately supplied `EMU-Partners-Presentation.private.json`. Confirm loading 21 partners. Only partner records are loaded; event IDs and event-partner links remain untouched.
4. Choose the original CSV in the second file input. Review the preview: **20 matched records**, no new identities, no validation errors, and **21 total partners** after applying. Already-current records appear as Unchanged, not as additional updates.
5. Click **Confirm and apply**, then accept the confirmation. Close the dialog. The actual records now appear in the Sponsors & Partners table. Search by name/contact/category/activity/phone/email, open a partner profile, filter relationship/sponsorship status or add a follow-up.
6. ID 12 remains separate and unchanged. IDs 3 and 12 are never merged by shared phone. Optional blank contact cells retain existing values. Participation remains independent from current relationship/sponsorship statuses. Source names, categories, activities, phone/email text and notes are preserved; no unsupported English translation is invented.

The approved original CSV is recognized by its checksum and the approved 20-row ID mapping. An edited CSV uses exact normalized-name matching rather than row-position matching; review any new/ambiguous identities before applying. Phone numbers are validated with a normalized comparison but saved exactly as supplied. Existing notes/history are retained, and repeating the import does not duplicate notes.

## Privacy and persistence

- Keep both private input files outside the extracted source directory, any shared HTTP root and Git checkout. Do not add them to GitHub or a public ZIP.
- Use a dedicated local browser profile for the director presentation. Private values persist on that browser/origin; other devices and browsers do not receive them automatically.
- Do not capture screenshots, browser traces, recordings or exports containing real contacts for public review. Review screenshots were generated in fresh contexts with fictional data only.
- JSON/CSV exports and local audit records may contain your private input. Treat them as private. LocalStorage is not encrypted or access-controlled; this is not a production private database.
- After the presentation, back up any follow-ups privately if needed, then reset the sanitized demo or clear this origin's site data. This does not modify the original CSV or backup.

The System Administrator, requester, department and management identities cannot open this module, import private partners, export contacts or view profiles. The Director can disable a staff member’s individual partner permission. Role Preview does not encrypt/remove previously imported data from browser storage; keep the private presentation profile dedicated and clear it afterward.
