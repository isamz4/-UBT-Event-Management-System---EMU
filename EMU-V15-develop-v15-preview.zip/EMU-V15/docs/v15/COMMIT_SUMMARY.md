## Calendar and availability update

Adds `v15/calendar.js` to extend existing V15 components with the published calendar, requester landing, operational view and anonymous availability checks. Changes `index.html`, `v15/bootstrap.js`, `styles.css`, the calendar regression expectations and adds a dedicated test suite. Updates API/permissions/feature/QA documentation and bilingual screenshots. Existing partner seed, official logos, permission grants and reference generator are unchanged.

## Final public catalog changes

- Extract only four approved CSV columns into public JSON and seed with stable IDs.
- Separate private overlay, backend placeholders, automatic migration and catalog filters.
- Preserve six-role permissions, private import, histories and event links.
- Refresh public screenshots; document privacy/history findings; add five regression tests.
- No merge, push or deployment.

# Public catalog update

Twenty approved public partner records now load automatically. Private contact imports remain optional and local. See [public/private mapping and historical privacy finding](PUBLIC_PARTNERS.md); this supersedes earlier references below to fictional public partner names.

# V15 development commit summary

Branch: `develop-v15`, based on preserved `develop-v14` (`c0423e7`). No merge, push or deployment is part of this change.

The V15 implementation commit adds:

- `v15/`: centralized models, mock business services, reusable UI, fourteen-step wizard, sixteen module controllers, workspace, bootstrap and responsive brand-preserving styles.
- Root and historical-directory entrypoints: load V15 assets while retaining V14 foundational components and approved branding.
- `app.js`: separate V15 persistence key and deferred V15 startup; allow numeric new request IDs without breaking legacy references.
- `vendor/`: pinned, locally served QR and spreadsheet libraries with provenance/licensing.
- `tests/test_v15.py`: browser/workflow regression suite; historical V14 suite explicitly excluded when the V15 entrypoint is present.
- `screenshots/v15/`: 48 sanitized bilingual desktop/mobile review captures.
- `README.md` and `docs/v15/`: setup, feature status, QA, presentation walkthrough, API/data models, Applications Department handoff and exact GitHub review instructions.

No original logo bytes or public partner seed records were changed. Private CSV/contact datasets remain outside the checkout. The source ZIP intentionally excludes Git history and private datasets.

To identify the exact implementation commit from the delivered checkout:

```sh
git log -1 --format='%h %s' develop-v15
git diff --stat develop-v14..develop-v15
```

## Follow-up: Director-mandated reference format

First-submission event-date references now use `EMUDDMMYY-NNN` with persistent per-date counters and collision checks, preserving assigned references through approved changes. References appear throughout event-related pages, reports, calendar and audit records. Draft messages, dropdown labels and report headers were corrected alongside regression coverage and backend uniqueness documentation.

## Follow-up: final Director acceptance requirements

Added a separate calendar publication approval workflow with decision history and change invalidation, tightened approved event-detail guards, normalized attendance duplicate matching, and added four Director acceptance tests. Full mandatory requirements and frontend/simulation/backend boundaries are retained in DIRECTOR_REQUIREMENTS.md.

## Final corrections: terminology, private presentation data and QR

Standardized Arabic booth labels and English University/External Booths. Added private baseline + approved CSV browser loading with exact source contacts and ID/history/link preservation, local-origin restrictions, and protection for unchanged profile text. Fixed the sponsorship-filter DOM-name collision. Added PNG QR downloads, four-module quiet zones, correct signed-in deep links, explicit unknown-event handling and independent image-decoding/UI workflow coverage. Public screenshots and ZIP remain synthetic; real contacts and the private backup stay outside the checkout.

## Role access and delegation clarification

Added centralized access.js policy for six roles and seven sanitized demo identities, independent Director-only staff delegation with expiration/revocation, authorized requester management, scoped routes/views/exports/files/API reads, role-aware dashboards and directory, read-only technical administration, and account/decision audit attribution. Added twelve permission acceptance tests, updated existing workflow identities, six new sanitized screenshots and the security/permissions handoff. No backend, push, merge or deployment is included.
