# Public catalog update

Twenty approved public partner records now load automatically. Private contact imports remain optional and local. See [public/private mapping and historical privacy finding](PUBLIC_PARTNERS.md); this supersedes earlier references below to fictional public partner names.

# V15 data models and relationships

`state.schemaVersion = 15`. Persistence is `emuV15` in localStorage plus blobs in IndexedDB `emu-v15-files`. V14 data is neither auto-imported nor modified. A local JSON restore can explicitly migrate a V14 backup after user confirmation; private files must remain outside the repository/HTTP root.

| Collection | Primary fields | Relationships |
| --- | --- | --- |
| requests | id (number or legacy string), immutable reference, ownerEmail, workflowStatus, status, submitted, details, decisions[] | eventId after approval |
| events | id, immutable reference, sourceRequestId, bilingual titles, date/start/end/setup/breakdown, campus/category, lifecycle, calendarPublication{status,history[]}, published, expectedAttendance, partners[], registration/check-in windows | One central record; all operational rows use eventId |
| tasks | id, eventId, bilingual title, dept, owner, due, priority, status, notes, attachments[] | eventId; synchronized event.tasks[] |
| approvals | id, eventId, dept, status, note, history[{status,reason,actor,time}] | eventId; one or more requested departmental approvals |
| reservations | id, eventId, venueId, date, start/end/setup/breakdown, status, equipment, notes | eventId + settings.venues.id |
| registrations | id, eventId, name, email, token, identity, checkedIn, checkedAt | eventId; unique event/email and one check-in |
| volunteers | id, eventId, name, gender, shift, location, tasks, status, hours, approvedHours | eventId |
| partners | id, exact official name, contactPerson, catAr/catEn, actAr/actEn, phone/email, previousParticipation, relationshipStatus, sponsorshipStatus, history[], nextFollowup, notes, notesHistory[] | events.partners[]; no phone-based identity merge |
| changes | id, eventId, field, oldValue, proposedValue, reason, impact, status, requester, reviewedBy, decisionReason | eventId; conflict check and value freshness before approved application |
| operations | id, eventId, item, owner, severity, status, notes, resolved | eventId; ten default operational checks on request approval |
| designs | id, eventId, type, bilingual content, dimensions/deadline, campus/display dates, status, published | eventId; Marketing approval before publication |
| expenses | id, eventId, item, amount, supplier, status, notes, attachments[] | eventId; Finance approval before Purchased |
| postReports | id, eventId, status, bilingual achievements, challenges, recommendations, satisfaction, summaryEn, attachments[] | One report per event; metrics derived from linked collections |
| users | id, name, email, role, department, status | Demo users only; no password or token |
| log | id, actor{name,role,department}, action, entity, time, before, after, reason | Entity reference is descriptive; local audit is not immutable |
| settings | departments[], venues[], categories[], workflow[], giveaways[], regulations, notifications, calendar, policies, policyStatus | Configures forms and required approval departments |

## Request details: fourteen sections

1. requester/email/phone/department/primaryOwner/alternateOwner
2. titleAr/titleEn/descriptionAr/descriptionEn/category/organizingUnit/date/startTime/endTime/setupTime/breakdownTime/campus/expectedAttendance/audience
3. venues[]: venueId/seating/tables/layout/stage/podium/equipment/notes
4. workshops[]: name/description/date/time/venue/capacity/equipment/owner/registration
5. booths[]: type/quantity/organizations/dimensions/signage/electricity/installation/access/security
6. volunteerQuantity/Gender/Tasks/Location/Shifts/Hours
7. media[]: type/contentAr/contentEn/dimensions/deadline/approvedLogos/screenCampus/displayStart/displayEnd
8. hospitalityType/Quantity/Timing/beneficiaries/universityGiveaways/externalGiveaways/supplier/hostResponsibility
9. budget/budgetOwner/sponsorship/purchases/financeRequired
10. performanceType/performerCount/duration/rehearsal/performanceEquipment/performanceBudget
11. guests[]: name/type/partnerId/session/arrival/restricted
12. certificates[]: type/issuer/quantity/nameAr/nameEn
13. attachments[]: id/name/type/size (blob remains in IndexedDB)
14. acknowledged

The draft form holds source values; approved event critical changes are recorded separately. Historical records may lack details and must not be filled with fabricated source information.

## Invariants

- New requests receive `EMUDDMMYY-NNN` on first successful submission, using the **event date**, not today's/submission date. Example: `EMU141026-001`, `EMU141026-002`, `EMU151026-001`. Drafts reserve no number.
- `referenceCounters` is a persisted map keyed by `EMUDDMMYY-`. Allocation scans existing request/event/audit references and the stored high-water counter in the same local transaction. Deleted records do not reset counters. A stale stored snapshot is rejected; storage failures roll back both request and counter. Exactly three sequence digits are allowed: after 999, submission is blocked with a clear error.
- Assigned references are immutable and shared by request and resulting event. Rejection/resubmission and approved date changes retain the original reference; new requests use the sequence of their own event date. Earlier issued demo/legacy references are preserved rather than silently renumbered. Legacy submitted requests without references are backfilled only if their event date is known.
- Production must atomically allocate the per-date sequence and enforce a **unique database constraint on reference across requests**. Use idempotent submission and a database transaction/row lock or equivalent; browser localStorage is not a distributed concurrency mechanism.
- Submission is not approval. Approval materializes one event with department approvals, venue reservations, media records and ten operational checklist entries.
- Approved event critical fields are changed only through reviewed change requests. Publication requires a separate request and explicit reviewed decision with actor/reason/history; event and Marketing approvals alone do not publish. Approved critical changes invalidate pending/approved publication and clear the local published state.
- Readiness derives from tasks, approvals, operational checks and confirmed reservations. High-severity incidents require explicit resolution.
- Closure requires full readiness and a Completed report with required content.
- Phone numbers never merge partners. IDs 3 and 12 stay separate; unmatched records are not deleted by import. Optional blanks preserve contacts; previous participation never infers either current status.
- Imported/new source text remains exact. Missing approved English translations fall back to Arabic; no machine translation is invented.
- Source seed and screenshots contain fictional partner identities and reserved `example.invalid` contacts only.

## Access model

`users` now includes six-role identity, department/college, Active/Inactive status, `requestAuthorized`, `operationalPermissions`, and independent `delegations.reviewEvent/reviewChange/reviewPublication` grants containing enabled/grantedBy/grantedAt/expiresAt. `accessSeeded` distinguishes initialized mock identity data. `technicalConfig.apiPath` is a demo relative path only. Report `managementAuthorized` is an explicit sharing flag for completed management reports. Approval actors include approvalAuthority, exact permission and delegatedBy in addition to user/role/time. See PERMISSIONS_MATRIX.md and RBAC_SECURITY_HANDOFF.md.
