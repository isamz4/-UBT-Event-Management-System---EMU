# Role access: frontend/backend security handoff

## What is implemented in this frontend

A centralized mock policy checks active local identities, six roles, requester authorization, ownership, departmental scope, independent staff delegations and optional expiration. Sidebars, routes, action controls, workspace tabs, reports, imports, exports and the mock list/get facade use that policy. Delegation decisions and identity switches are auditable in local data. The UI preserves Arabic RTL, English LTR and the approved brand.

This is **not a production security boundary**. The complete demo state, including previously imported private partners, can remain in browser memory/localStorage. A person with browser developer tools can inspect or alter that state and the JavaScript. Role Preview intentionally switches mock identities. Client-side filtering does not make shared-browser private data secure. Keep private presentations in a dedicated profile and clear/reset private site data afterward. No authentication server, signed tokens or institutional identity verification has been built.

## Required backend enforcement

1. Resolve the real actor from university SSO, never from a frontend role dropdown, email parameter or localStorage. A technical administrator must not automatically receive an EMU business role.
2. Return server-filtered DTOs. Only Director and appropriately authorized EMU Staff may fetch partner records/contact fields. Remove sponsor contacts from event/request/report/analytics responses for every other role. Technical configuration and identity-directory endpoints must not include sponsor data or business backups.
3. Enforce active-user and specifically authorized requester status on create/save/submit/change APIs. Scope requester reads and changes to their own requests/events. Scope Supporting Department queries, updates, files and decisions to assigned department rows.
4. Store separate event, critical-change and calendar-publication authority. Authorizing a department task or Marketing prerequisite must never imply any of these three approvals.
5. Store each staff delegation independently with grant ID, granting Director, permission, start/expiry and revocation state. Only the Director may grant/revoke, and only to an EMU Staff target. Recheck grants at decision time; stale JWT claims/caches must not preserve revoked powers. Reject role changes and user deactivation when evaluating an existing grant.
6. Commit the decision and immutable audit together. Record authenticated actor ID, effective role, exact delegated permission/grant ID, granting Director, before/after version, reason and timestamp. Do not trust the frontend's Director/delegated classification.
7. Enforce immutable `EMUDDMMYY-NNN` references, uniqueness/idempotency, approved-field locking, current old-value checks, event relationships, separate publication decisions and invalidation after material changes in server transactions.
8. Authorize every file upload/download and export; do not rely on unknown IDs or hidden buttons. Management reports require completed/explicitly shared status and an institutionally defined redacted DTO. Unstructured text/images can contain sensitive material: the report owner must review sharing and the backend must apply the approved classification policy.
9. Enforce attendance uniqueness and check-in state transactionally across devices. Return aggregate counts separately from attendee PII. Server authorization must distinguish attendee registration from staff-recorded check-in.
10. Separate technical configuration, user provisioning and business authority in actual administrative tools. Protect audit retention, data encryption, backups, transport security and privacy controls according to university policy.

## Expected API additions

| API | Required authority / behavior |
| --- | --- |
| GET `/session` | SSO-derived active identity, role, department, scoped capabilities and grant IDs |
| GET `/users` | Director directory; explicitly reduced technical directory where approved |
| POST/PATCH `/users[/{id}]` | Director-controlled operational role/requester authorization and active state; separate approved technical provisioning policy |
| PUT `/users/{id}/delegations/{permission}` | Director only, EMU Staff target, independent enabled/expiry/version, audit |
| DELETE `/users/{id}/delegations/{permission}` | Immediate Director revocation, invalidate stale authorization caches |
| PATCH `/users/{id}/operational-permissions` | Director-controlled individual staff scopes |
| POST `/requests/{id}/decisions` | Director or active `reviewEvent` grant; record actual authority |
| POST `/changes/{id}/decisions` | Director or active `reviewChange` grant |
| POST `/events/{id}/publication/decisions` | Director or active `reviewPublication` grant, independent prerequisite checks |
| GET `/partners[/{id}]` and partner imports/exports | Director / authorized Staff only, server-filtered responses |
| GET `/reports/{id}` | Operational EMU authority or explicitly approved management-redacted report |

The frontend `E15.api` remains a local adapter. Controllers currently call centralized synchronous mock services; integration must replace/await real APIs and server confirmation. A Promise wrapper alone is not a connected backend.

## Acceptance evidence and remaining limits

Regression tests cover direct service denials, scope-filtered UI/API reads, independent grants, revocation/expiration, authorized/unlisted requesters, own-request access, department scope, system/business separation, confidential sponsor sentinels, report sharing, role switching and bilingual responsive navigation. Existing request/venue/attendance/report/reference workflows remain regression targets.

No SSO, multi-user server, physical-device permission test, production audit service or deployment was available. Same-origin tabs recheck the latest stored identity/grants, close old dialogs and refresh role UI on storage changes; storage conflicts still require reloading before a write. Distributed revocation, transactions and cross-device updates belong to the backend. The optional delegation start date is not implemented; expiration is implemented. Native Role Preview accounts are sanitized, not real university users.
