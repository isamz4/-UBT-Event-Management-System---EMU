PROJECT: UBT EVENT MANAGEMENT SYSTEM – EMU
VERSION: V15
TASK: COMPLETE ROLE-BASED ACCESS & DELEGATION SYSTEM

IMPORTANT:
This is an approved clarification from the user
regarding the Events Management Unit's permissions.

Work on the existing develop-v15 branch.

Preserve:
- All current V15 features
- Approved V14/V15 premium visual design
- Official UBT and EMU logos
- Arabic RTL and English LTR
- Responsive desktop and mobile layouts
- Existing event data and relationships

Do not merge, push, or deploy.

==================================================
1. USER ROLES
==================================================

Implement six user roles:

1. System Administrator
2. EMU Director
3. EMU Staff
4. Authorized Event Requester
5. Supporting Department
6. Management Viewer

Use centralized permission definitions.

Avoid hardcoding permissions separately
inside individual UI components.

==================================================
2. EMU DIRECTOR
==================================================

The EMU Director has full operational authority
over the Events Management Unit.

The director can:

- View all events and requests
- Approve/reject event requests
- Approve/reject event change requests
- Approve/reject calendar publication requests
- Manage event operations
- View and manage sponsors and partners
- View executive insights
- Access EMU Intelligence
- View activity logs
- Manage EMU staff permissions
- Delegate approval authority to EMU staff
- Revoke delegated authority

The director must have a dedicated
Executive Dashboard.

==================================================
3. DELEGATED APPROVAL AUTHORITY
==================================================

The EMU Director can delegate specific
approval permissions to selected EMU staff.

Delegable permissions:

- Approve event requests
- Approve event change requests
- Approve calendar publication requests

Each permission must be independently configurable.

Requirements:

1. Delegation can only be granted by the EMU Director.
2. Delegation can only be assigned to EMU Staff.
3. The director can revoke permissions at any time.
4. Delegated staff can approve only the actions
   explicitly authorized by the director.
5. Staff cannot delegate permissions to others.
6. Delegation does not grant full director access.
7. Show delegated permissions clearly
   in the staff profile.
8. Record delegation changes in the activity log.
9. Record who approved each request.
10. Record whether approval was made by the director
    or by a delegated staff member.

Optional:
- Delegation start date
- Delegation expiration date

==================================================
4. SPONSORS & PARTNERS ACCESS
==================================================

Sponsors and partners are confidential
EMU operational data.

ONLY the following roles may access
the Sponsors & Partners module:

- EMU Director
- EMU Staff

All other roles must be denied access.

This includes:

- System Administrator
- Authorized Event Requester
- Supporting Department
- Management Viewer

Hide the module from unauthorized sidebars.

Also block unauthorized access through
direct navigation or application routes.

Do not expose sponsor contact information
in dashboards, exports, search results,
or event views for unauthorized roles.

Technical administrators must not receive
business-data access automatically.

==================================================
5. AUTHORIZED EVENT REQUESTERS
==================================================

Not every university employee can submit
an event request.

Only specifically authorized individuals
from university colleges and departments
may create and submit requests.

The EMU Director can:

- Add authorized requesters
- Select their college or department
- Activate/deactivate their access
- Revoke submission permission

Authorized requesters can:

- Create event requests
- Save drafts
- Submit requests
- View their own requests
- Track approval status
- Edit their own drafts
- Respond to review feedback
- Request changes to their approved events
- View publicly published events

They cannot:

- View other requesters' private requests
- Approve event requests
- Approve change requests
- Approve publication requests
- Manage sponsors and partners
- Access internal EMU reports
- Manage system permissions

==================================================
6. EMU STAFF
==================================================

EMU Staff can:

- View and manage operational events
- Prepare and coordinate events
- Manage tasks and venue requirements
- Manage volunteers
- Manage attendance
- Manage sponsors and partners
- Prepare reports
- View operational dashboards

By default, EMU Staff cannot:

- Approve event requests
- Approve change requests
- Approve calendar publication requests
- Grant permissions
- Revoke permissions

Approval actions become available only
when explicitly delegated by the director.

==================================================
7. SUPPORTING DEPARTMENTS
==================================================

Supporting departments include:

- Marketing
- IT
- Facilities
- Security
- Finance
- Student Affairs
- Other approved departments

Each department user sees:

- Their assigned tasks
- Relevant event details
- Deadlines
- Required files
- Department-specific approvals
- Task status

They must not see:

- Confidential sponsor records
- Other departments' restricted information
- Internal EMU administrative settings
- Unrelated private event requests

Department-level task approvals must not
be confused with EMU event approval authority.

==================================================
8. MANAGEMENT VIEWER
==================================================

Management Viewer is read-only.

Can view:

- Executive Dashboard
- Approved event summaries
- Published calendar
- Executive Insights
- Authorized management reports
- EMU Intelligence summaries

Cannot:

- Create or edit records
- Approve requests
- Manage sponsors
- Access private sponsor contacts
- Manage permissions

==================================================
9. SYSTEM ADMINISTRATOR
==================================================

System Administrator represents the
university Applications Department.

Responsibilities:

- Technical configuration
- Integration readiness
- System maintenance
- Authentication integration
- API configuration

Technical administration must remain
separate from EMU business authority.

System Admin must not automatically
receive access to confidential sponsor data
or event approval powers.

==================================================
10. ROLE-BASED USER INTERFACE
==================================================

Implement dynamic navigation.

Each role should see only the modules
and actions relevant to their permissions.

Include:

- Role-specific dashboards
- Role-specific sidebar navigation
- Permission-aware action buttons
- Restricted route handling
- Clear access-denied messages
- Read-only states
- Permission-based data filtering

All UI elements must update immediately
when the active demo role changes.

==================================================
11. ROLE PREVIEW MODE
==================================================

Add a polished frontend demonstration feature:

"معاينة الصلاحيات"
"Role Preview"

Allow switching between demo identities:

- EMU Director
- EMU Staff
- Delegated EMU Staff
- Authorized Event Requester
- Supporting Department
- Management Viewer
- System Administrator

When switching identities:

- Update the sidebar
- Update dashboard metrics
- Update accessible records
- Update visible actions
- Update approval buttons
- Update available reports

Use realistic sanitized demo accounts.

Make it obvious that Role Preview is
a FRONTEND DEMONSTRATION FEATURE.

==================================================
12. PERMISSIONS MANAGEMENT PAGE
==================================================

Enhance Users & Access with:

- User directory
- Role assignment
- College/department
- Active/inactive status
- Authorized requester management
- Staff delegation management
- Individual permission toggles
- Delegation expiration
- Search and filters
- User details
- Audit history

Create a premium interface matching V15.

==================================================
13. AUDIT & ACCOUNTABILITY
==================================================

Record frontend demo activity for:

- Role changes
- Delegation grants
- Delegation revocations
- Event approvals
- Change approvals
- Publication approvals
- Requester authorization changes

Show:

- Actor
- Action
- Target user or event
- Timestamp
- Previous value
- New value

==================================================
14. FRONTEND-ONLY ARCHITECTURE
==================================================

This is a frontend-only university project.

Use:
- Centralized permissions
- Mock user identities
- Mock authorization service
- Local demo persistence
- Reusable access-control helpers

Do not build a production authentication server.

Clearly document that production access
control must be enforced by the backend.

Frontend hiding alone is not security.

==================================================
15. QUALITY ASSURANCE
==================================================

Test:

1. Director approval works.
2. Nondelegated staff cannot approve.
3. Delegated staff can approve permitted actions.
4. Delegated staff cannot approve other actions.
5. Revocation takes effect immediately.
6. Unauthorized requesters cannot submit.
7. Authorized requesters can submit.
8. Requesters see only their own private requests.
9. Supporting departments see assigned tasks only.
10. Management Viewer cannot edit.
11. Unauthorized roles cannot open Sponsors.
12. Sponsor data does not appear in unauthorized views.
13. Role switching updates the interface.
14. Arabic and English work correctly.
15. Desktop and mobile layouts remain polished.
16. Existing V15 workflows do not regress.

==================================================
16. DELIVERABLES
==================================================

Provide:

1. Updated V15 preview ZIP.
2. Permissions matrix documentation.
3. Screenshots of Users & Access.
4. Screenshots of Role Preview.
5. Test results.
6. Frontend/backend security handoff notes.
7. Commit summary.

Do not merge, push, or deploy.