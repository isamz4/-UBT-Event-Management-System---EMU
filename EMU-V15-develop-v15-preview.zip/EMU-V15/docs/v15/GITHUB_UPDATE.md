# Exact GitHub update instructions — actions not executed

Current work is isolated on `develop-v15`. `develop-v14` remains available as the prior version. Main and GitHub Pages were not modified, merged or deployed.

## Review locally first

```sh
git switch develop-v15
git status --short
CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -p 'test_v15.py' -v
```

Review the feature matrix, screenshots and private-data exclusion. The downloadable ZIP contains source only, not Git history or private datasets.

## Upload the development branch only, when authorized

From a checkout with the prepared branch and configured repository remote:

```sh
git remote -v
git switch develop-v15
git log --oneline develop-v14..develop-v15
git push -u origin develop-v15
```

These commands are instructions for the owner; no push was performed by this implementation. If your computer only has the ZIP, it has no branch metadata: obtain the development branch/commits from this workspace or copy the reviewed source into a fresh `develop-v15` branch before committing. Never add private datasets or CSV files.

After the push, open a **draft pull request** from `develop-v15` to the chosen review branch. Keep it unmerged until V15 is approved. Confirm existing repository automation does not deploy development branches before pushing.

Do not run a main-branch merge, change Pages settings, or trigger a deployment as part of this review. Publishing or merging requires a separate explicit approval.
