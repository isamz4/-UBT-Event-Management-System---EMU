# University calendar acceptance run

`QR_DECODER_PATH=/tmp/emu-qr-decoder CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -v`

**92 discovered: 67 passed, 25 skipped, 0 failed.** The 25 skips are the retained V14-only baseline suite, explicitly not counted as V15 passes. The 67 passes comprise 50 existing V15 workflow/RBAC/QR tests, 5 public-partner tests and 12 university-calendar tests. An additional targeted calendar rerun verifies the final empty-date handling and refreshes calendar screenshots.

New coverage: all six roles see only approved + independently published events; public details and actual JSON download omit internal fields; requester login and Role Preview land on the calendar; existing roles retain dashboards; requester actions and own-request scoping work; operational access obeys staff venue permission; availability is read-only, anonymous and venue/time specific; tentative/confirmed/setup/breakdown/boundary/multi-day cases are covered; confirmed submission conflicts are blocked; publication delegation, expiration, revocation and unsafe public URLs are tested. Month/week/list render in Arabic/English at 1440, 1024, 768, 390 and 320 with no document overflow. The existing 160 module/language/width checks and independent QR PNG decoding also pass.

The real private CSV was separately tested outside the checkout in Arabic and English: 20 source records + retained ID 12; histories, contacts, search/filter/edit/reload and event links preserved. No private screenshots were taken. The current public token scan finds zero private matches; original logos remain byte-identical. Eleven new calendar screenshots accompany the 54 refreshed V15 captures. See [calendar scope, screenshot links and remaining limitations](UNIVERSITY_CALENDAR.md).

---

# V15 quality assurance

## Reproduce

Use Python 3, the Python Playwright package, Node.js for syntax checking, and Chromium. The browser test executable defaults to `/usr/bin/chromium`.

```sh
CAPTURE_SCREENSHOTS=1 python3 -m unittest discover -s tests -p 'test_v15.py' -v
node --check app.js
for file in v15/*.js; do node --check "$file"; done
git diff --check
```

The test server serves only the public checkout on an ephemeral loopback port. Each test uses a fresh browser context, approved public catalog data and synthetic private test values. The screenshot test refreshes `screenshots/v15/`.

Install `zxing-cpp` and `Pillow` for the independent QR PNG test; see QR_VERIFICATION.md. The final validation run used that decoder and enabled screenshot capture, with no skipped tests.

## Verified coverage

- 55 automated tests passed: 50 browser/workflow tests plus 5 public-catalog regression tests. Coverage (including the enabled screenshot test), including the complete request → review → approval → event workspace → tasks/venue/operations → attendance/report → closure scenario.
- All 16 modules × Arabic/English × widths 1440, 1024, 768, 390 and 320: 160 layout combinations, correct document direction and no document horizontal overflow.
- Actual UI navigation, 14-step request wizard, CRUD forms, manager decisions, legacy request detail/conversion, eleven workspace tabs and persisted reloads.
- Event-date `EMUDDMMYY-NNN` references: first-submission allocation, per-date sequences, collision recovery, persistent high-water counters, stale-store rejection, 999 exhaustion rollback, approved date change/reload immutability, and reference visibility across all requested modules in both languages.
- Required fields, immutable references, unknown-role denial, ownership, departmental approvals, Marketing/Finance gates, volunteer-hour limits and closure conditions.
- Director acceptance: separate publication request/decision/history and withdrawal, event/Marketing prerequisites, approved-change invalidation, publication/approved-detail edit bypass guards, shared partner/report counts, registered-versus-attended deltas and whitespace/case normalized duplicate registrations.
- Venue overlap including setup/breakdown buffers, critical-field change requests, stale/invalid changes and independent calendar publication.
- Real locally generated QR SVG and registration route, registration/check-in windows, capacity and duplicate checks, CSV/XLSX downloads.
- Actual IndexedDB file upload/download bytes; Excel certificate-name import; report photo attachment and printable report.
- Partner CSV preview and explicit confirmation, exact-name identity matching, shared-phone records kept separate, participation independent from current statuses, blank optional contact preservation, historical notes and repeat-import detection. No real private dataset is used in committed automated fixtures. Separate redacted private verification also passed in both languages.
- Corrupted local storage recovery without overwriting the damaged original; settings CRUD, invalid restore rejection, V14 storage isolation and original event/TBD date preservation.
- Original logo byte hashes and sanitized public demo fixtures.
- 54 review screenshots: all sixteen modules in both languages, workspace, filled request wizard, print reports and five mobile views in both languages.

## Additional checks

JavaScript syntax and whitespace checks pass. The private contact-token scan reports zero matches in the current public text files and no CSV files in the checkout. Original UBT and both approved EMU assets remain byte-identical. This scan does not remove contacts from pre-existing Git history.

The source ZIP is additionally extracted and smoke-tested independently before delivery. It contains no private dataset or Git history.

## Scope and limits

Tests use desktop Chromium and emulated viewport sizes, not physical devices or Safari/Firefox. No university backend, SSO, email, SMS, shared cross-device data, malware scanning or real deployment was available to test. Local roles are a demonstration, not production security. Browser print/PDF output still requires user review. The historical V14 suite is explicitly skipped in the V15 entrypoint; it is not counted as passed V15 coverage. V14 itself remains preserved on `develop-v14`.

Final-correction verification also covers exact booth terminology, a private baseline + CSV browser import preserving IDs/history/links, and independent decoding of actual PNG downloads for every approved demo event, followed by registration/check-in/counts/CSV. Actual private-data checks run outside the checkout with no screenshots or contact-value logs. See PRIVATE_PARTNERS.md and QR_VERIFICATION.md.

Private acceptance run: the actual approved 20-row CSV was loaded through browser file inputs in Arabic and English, producing 21 partners. ID 12, source fields, histories and event relationships were verified unchanged; search/filter/profile editing/follow-ups and actual names after reload passed. No private screenshots/traces were recorded. The verification script and input files remain outside the public checkout.

Role-access acceptance adds 12 tests: independent delegation and authority attribution; revocation and expiration; active/authorized requester and own-record scope; supporting-department restrictions; sponsor sentinels excluded from unauthorized routes/views/API/exports; technical/business separation; Director directory UI and immediate role changes; management-report sharing; and inactive/unknown fail-closed behavior. Seven identities were exercised through their visible modules in both languages at 1440 and 390 widths, in addition to the existing sixteen-module/five-width Director matrix.

A separate same-origin two-tab test verifies that a Director revocation in one tab removes cached approval and sponsor permissions in the staff tab.

## Approved public catalog release

Run `python3 -m unittest discover -s tests -p 'test_public_partners.py' -v` for the five additional checks: clean-browser automatic loading, allowlisted network JSON, exact stable IDs and event links, bilingual search/category/participation filters, and legacy fictional-data migration. All five passed. The 50-test suite also passed without skips with independent QR image decoding enabled. Private browser verification passed against all 20 CSV rows plus retained ID 12, without private screenshots. See [field mapping and historical exposure](PUBLIC_PARTNERS.md).
