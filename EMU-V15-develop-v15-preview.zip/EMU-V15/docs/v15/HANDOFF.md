# V15 Applications Department handoff

## Delivered frontend

A dependency-light, classic-script browser application extending V14's approved brand/components. Sixteen navigable modules, fourteen request steps and eleven event workspace tabs use a centralized state model and local workflow services. No production backend, deployment workflow or live-site change is included.

Read `README.md`, `DATA_MODELS.md`, `API_CONTRACTS.md`, `FEATURE_MATRIX.md`, `DIRECTOR_REQUIREMENTS.md` and `QA.md` before integration.

## Runtime layout

1. `data.js` supplies fictional public fixtures.
2. `app.js` supplies the V14 component/storage/accessibility foundation. Its automatic V14 bootstrap is suppressed on the `data-v15` entry points.
3. Locally served QR/spreadsheet libraries load without CDNs.
4. `models.js` initializes V15 collections; V15 storage is isolated from V14.
5. `services.js` validates local mutations, applies transactions and records before/after audit.
6. `ui.js`, `wizard.js`, `modules.js` render reusable components and connected workflows.
7. `bootstrap.js` wires navigation/roles, the promise-based mock API facade, file links and final initialization.

The root and historical nested entry point use the same implementation. The nested directory is an entry-point compatibility path, not a second application.

## Replace, rather than trust, the mock boundaries

- Replace localStorage with authenticated API reads/writes and server pagination/concurrency. Current state is convenient browser persistence, not shared storage.
- Replace sessionStorage demo role/email with SSO claims from `/session`; remove demonstration role switching in production.
- Replace `E15.transaction`/workflow operations with server transactions. Update asynchronous controllers to await server confirmation before updating local views.
- Replace IndexedDB file storage with authorized upload/download APIs. Metadata survives JSON backup; blobs do not travel with the backup.
- Replace local audit with immutable server events. Client audit is useful demonstration evidence but editable by the user.
- Replace the current-origin QR URL with a configured HTTPS public registration route. Identity checks must become institutional or approved external verification.
- Connect email/SMS/push delivery and operational integrations. Current notification preferences only affect local prioritization.
- Establish exact department/manager/financial authorities, source-of-truth venues/capacities and approved policies with EMU. Defaults are fictional/proposed examples.
- Preserve the approved navy/white EMU originals, UBT logo and Arabic-first direction logic. Do not crop or recolor the branding assets.

## Migration and privacy

The prior private partner development dataset remains outside this checkout. Public source/fixtures/screenshots must stay fictional. An administrator can explicitly restore a local JSON backup or preview/apply a CSV in a private browser context. Do not copy such files under the static server root.

The approved eight-column import baseline and source checksum support stable-ID matching. Partner 3 and 12 are intentionally separate. New/unmatched records require preview and confirmation; imported rows do not delete absent records or infer current statuses. Preserve original names, notes and follow-up histories.

Historical Git commits predate current sanitization and may contain legacy contact information; this release neither republishes nor rewrites that history. Coordinate any repository-history cleanup separately.

## Suggested integration sequence

1. Session/SSO and read-only event/request APIs.
2. Draft/submission/reference issuance and approval/materialization transaction.
3. Venue inventory, reservations/conflicts and task/department approval APIs.
4. Private partners, files and field-level guest access.
5. Registration/check-in and volunteer-hour approval.
6. Changes, operational incidents, reports/closure and finance/marketing gates.
7. Insights, exports, notifications, audit and settings governance.
8. Browser/device/accessibility/security testing against real APIs before deployment approval.

## Acceptance scenario

Create request → submit (still pending) → manager review → approve → open stable event workspace → assign tasks → review/confirm venue → link partners → configure/register/check in attendee → complete department and event-day checklists → draft/complete bilingual report → close event → reload and verify reference/relationships persist. Negative cases must still block at the API layer: unauthorized owner/department, reservation overlap, duplicate check-in, Marketing/Finance bypass, stale change and early closure.

## Not supplied as production capabilities

SSO, backend RBAC, multi-user database, delivery services, institutional booking/finance integrations, immutable audit storage, public infrastructure, antivirus/file quarantine and server PDF services. These are explicitly university backend/integration responsibilities, not hidden frontend placeholders.

The separate calendar-publication workflow requires its own authorized decision and audit history. Do not map event approval or Marketing approval directly to a public feed. Review Director acceptance and the documented migration of prior demonstration publication flags before integration.

Current authorization design: read PERMISSIONS_MATRIX.md and RBAC_SECURITY_HANDOFF.md. The new access.js policy and projection layer run before the final bootstrap; historical broad Admin permissions are superseded. Backend authorization, including sponsor DTO filtering and immediate delegation revocation, is mandatory.
