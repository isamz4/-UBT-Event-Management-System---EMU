"""V15 workflow/browser suite. Run: python3 -m unittest discover -s tests -p 'test_v15.py' -v"""
import functools,http.server,json,os,threading,unittest,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
MODULES=['dashboard','events','calendar','requests','tasks','venues','attendance','volunteers','partners','changes','postreports','insights','operations','access','log','settings']
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
class V15Frontend(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)));threading.Thread(target=cls.server.serve_forever,daemon=True).start();cls.url=f'http://127.0.0.1:{cls.server.server_port}/';cls.play=sync_playwright().start();cls.browser=cls.play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.play.stop();cls.server.shutdown();cls.server.server_close()
 def setUp(self):
  self.context=self.browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');self.p=self.context.new_page();self.errors=[];self.p.on('pageerror',lambda e:self.errors.append(str(e)));self.p.goto(self.url)
 def tearDown(self):self.context.close();self.assertEqual(self.errors,[])
 def login(self,role='EMU Director',language='en'):
  self.p.evaluate('([r,l])=>{sessionStorage.setItem("emuLogin","1");sessionStorage.setItem("emuRole",r);sessionStorage.setItem("emuEmail",state.users.find(u=>u.role===r&&u.status==="Active")?.email||"unknown@example.invalid");lang=l;init()}',[role,language])
 def details(self):
  return {'requester':'Demo requester','email':'requester@example.invalid','phone':'+19995550123','department':'Demo college','primaryOwner':'Demo owner','alternateOwner':'Demo alternate','titleAr':'ملتقى تجريبي شامل','titleEn':'Complete frontend demo forum','descriptionAr':'وصف تجريبي','descriptionEn':'Demo description','category':'Academic','organizingUnit':'EMU','date':'2027-05-12','startTime':'12:00','endTime':'14:00','setupTime':'11:00','breakdownTime':'15:00','campus':'Corniche','expectedAttendance':40,'audience':'University Community Only','venues':[{'venueId':'1','seating':40,'tables':4,'layout':'Theater','equipment':'Screen'}],'workshops':[{'name':'Demo workshop','date':'2027-05-12','capacity':20}],'media':[{'type':'Poster','contentAr':'إعلان تجريبي','status':'Draft'}],'acknowledged':True}
 def approved(self):
  self.login();return self.p.evaluate('(d)=>{const r=E15.request.save(d,null,true);E15.request.review(r.id,"Approved","Demo manager decision");return {requestId:r.id,eventId:r.eventId,reference:r.reference}}',self.details())
 def test_all_16_modules_both_languages_five_widths(self):
  self.login()
  for language in ['ar','en']:
   self.p.evaluate('(l)=>{lang=l;init()}',language)
   for width in [1440,1024,768,390,320]:
    self.p.set_viewport_size({'width':width,'height':1000})
    for module in MODULES:
     with self.subTest(language=language,width=width,module=module):
      self.p.evaluate('(m)=>render(m)',module)
      self.assertTrue(self.p.locator('#content').inner_text().strip())
      self.assertLessEqual(self.p.evaluate('document.documentElement.scrollWidth-innerWidth'),1)
      self.assertEqual(self.p.locator('html').get_attribute('dir'),'rtl' if language=='ar' else 'ltr')
 def test_login_roles_navigation_and_v14_storage_isolation(self):
  self.assertEqual(self.p.locator('html').get_attribute('lang'),'ar')
  self.assertEqual(self.p.locator('#loginRole option').count(),6)
  self.p.evaluate('localStorage.setItem("emuV5","DO-NOT-CHANGE-V14")')
  self.p.locator('#loginEmail').fill('director@example.invalid');self.p.locator('#signIn').click()
  self.assertEqual(self.p.locator('.nav [data-page]').count(),16)
  for module in MODULES:
   self.p.locator(f'.nav [data-page="{module}"]').click();self.assertEqual(self.p.locator('.nav [aria-current="page"]').get_attribute('data-page'),module)
  self.assertEqual(self.p.evaluate('localStorage.getItem("emuV5")'),'DO-NOT-CHANGE-V14')
 def test_request_wizard_14_steps_draft_and_submission(self):
  self.login();self.p.locator('[data-v15="new-request"]').first.click()
  self.assertIn('1/14',self.p.locator('#modalTitle').inner_text())
  for key,value in {'requester':'UI Demo','email':'ui@example.invalid','phone':'+19995550123','department':'Demo','primaryOwner':'Demo Owner'}.items():self.p.locator('#w-'+key).fill(value)
  self.p.locator('[data-v15="wizard-draft"]').click();self.assertIsNone(self.p.evaluate('state.requests[0].reference??null'))
  self.p.locator('[data-v15="wizard-next"]').click();self.assertIn('2/14',self.p.locator('#modalTitle').inner_text())
  for key,value in {'titleAr':'ملتقى تجريبي','titleEn':'UI Demo Forum','organizingUnit':'EMU','date':'2027-05-12','startTime':'12:00','endTime':'14:00','expectedAttendance':'40'}.items():self.p.locator('#w-'+key).fill(value)
  self.p.locator('[data-v15="wizard-next"]').click();self.p.locator('[data-v15="wizard-add"]').click();self.p.locator('#repeat-seating').fill('40');self.p.locator('#repeatSave').click()
  for _ in range(11):self.p.locator('[data-v15="wizard-next"]').click()
  self.assertIn('14/14',self.p.locator('#modalTitle').inner_text())
  self.p.locator('#w-acknowledged').check();self.p.locator('[data-v15="wizard-submit"]').click()
  self.assertEqual(self.p.evaluate('state.requests[0].workflowStatus'),'Submitted')
  reference=self.p.evaluate('state.requests[0].reference');self.assertEqual(reference,'EMU120527-001')
  self.assertFalse(self.p.evaluate('!!state.requests[0].eventId'))
  self.p.reload();self.assertEqual(self.p.evaluate('state.requests[0].reference'),reference)
 def test_validation_rejects_invalid_requests_and_duplicate_references(self):
  self.login()
  result=self.p.evaluate('(d)=>{const a=E15.request.save({},null,false),b=E15.request.save({},null,false);let invalid=false;try{E15.request.save({},null,true)}catch(e){invalid=true}return {draftsUnnumbered:!a.reference&&!b.reference,invalid}}',self.details())
  self.assertEqual(result,{'draftsUnnumbered':True,'invalid':True})
 def test_full_demo_workflow_through_report_and_closure(self):
  item=self.approved();eid=item['eventId'];self.p.evaluate('(id)=>E15.handlers.workspace(id)',str(eid))
  self.assertEqual(self.p.locator('[role="tab"]').count(),11)
  for tab in ['overview','original','schedule','tasks','guests','volunteers','budget','media','attendance','changes','report']:
   self.p.locator(f'[data-v15="workspace-tab"][data-id="{tab}"]').click();self.assertTrue(self.p.locator('[role="tabpanel"]').inner_text().strip())
  self.p.evaluate('(id)=>{E15.stage(id,"Preparation");E15.record.save("tasks",{eventId:id,titleAr:"مهمة تجريبية",titleEn:"Demo task",dept:"IT",owner:"Demo",due:"2027-05-10",priority:"High",status:"Pending"})}',eid)
  blocked=self.p.evaluate('(id)=>{try{E15.stage(id,"Event Day");return false}catch(e){return true}}',eid);self.assertTrue(blocked)
  self.p.evaluate('(id)=>{for(const a of [...state.approvals.filter(a=>a.eventId===id)])E15.approval(a.id,"Approved","Department ready");for(const t of [...state.tasks.filter(t=>t.eventId===id)])E15.record.save("tasks",{eventId:id,status:"Done"},t.id);for(const o of [...state.operations.filter(o=>o.eventId===id)])E15.record.save("operations",{eventId:id,status:"Done",resolved:true},o.id);for(const r of [...state.reservations.filter(r=>r.eventId===id)])E15.record.save("reservations",{...Object.fromEntries(Object.entries(r).filter(([k])=>k!=="id")),status:"Confirmed"},r.id);E15.stage(id,"Event Day");E15.stage(id,"Post-Event Reporting")}',eid)
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.stage(id,"Closed");return false}catch(e){return true}}',eid))
  self.p.evaluate('(id)=>{E15.record.save("postReports",{eventId:id,status:"Completed",achievements:"أهداف محققة",achievementsEn:"Goals achieved",challenges:"Demo challenges",recommendations:"Demo recommendation",satisfaction:5});E15.stage(id,"Closed")}',eid)
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).lifecycle',eid),'Closed')
  self.p.reload();self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).reference',eid),item['reference'])
 def test_venue_conflicts_include_setup_and_confirmation_requires_approval(self):
  self.login();result=self.p.evaluate('()=>{const base={eventId:15001,venueId:1,date:"2027-06-10",startTime:"12:00",endTime:"14:00",setupTime:"11:00",breakdownTime:"15:00",status:"Pending"};E15.record.save("reservations",base);let conflict=false,confirmation=false;try{E15.record.save("reservations",{...base,startTime:"14:30",endTime:"16:00",setupTime:"14:00",breakdownTime:"17:00"})}catch(e){conflict=true}try{E15.record.save("reservations",{...base,date:"2027-06-11",status:"Confirmed"})}catch(e){confirmation=true}return {conflict,confirmation}}');self.assertEqual(result,{'conflict':True,'confirmation':True})
 def test_attendance_windows_duplicates_qr_and_exports(self):
  self.login();self.p.evaluate('E15.filter.attendance={eventId:15001};render("attendance")')
  self.assertEqual(self.p.locator('.qr-code svg').count(),1)
  self.assertIn('15001',self.p.evaluate('location.origin+location.pathname+"?register=15001"'))
  self.p.locator('[data-v15="register"]').click();self.p.locator('#f-name').fill('Demo Guest');self.p.locator('#f-email').fill('guest@example.invalid');self.p.locator('#v15Save').click()
  aid=self.p.evaluate('state.registrations.at(-1).id');self.p.locator(f'[data-v15="checkin"][data-id="{aid}"]').click()
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.attendance.checkin(id);return false}catch(e){return true}}',aid))
  self.assertTrue(self.p.evaluate('()=>{try{E15.attendance.register(15001,{name:"Again",email:"guest@example.invalid"});return false}catch(e){return true}}'))
  with self.p.expect_download() as dl:self.p.locator('[data-v15="qr-download"]').click()
  self.assertIn('<svg',Path(dl.value.path()).read_text())
  with self.p.expect_download() as dl:self.p.locator('[data-v15="attendance-export"]').click()
  self.assertIn('guest@example.invalid',Path(dl.value.path()).read_text(encoding='utf-8-sig'))
 def test_approved_fields_lock_and_change_review(self):
  item=self.approved();eid=item['eventId'];self.assertTrue(self.p.evaluate('(id)=>{try{E15.record.save("events",{date:"2027-05-13"},id);return false}catch(e){return true}}',eid))
  self.p.evaluate('(id)=>{const c=E15.change.request(id,"date","2027-05-13","Date adjustment","Venue review");E15.change.review(c.id,true,"Approved adjustment")}',eid)
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).date',eid),'2027-05-13')
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).reference',eid),item['reference'])
 def test_roles_supporting_department_and_sensitive_view(self):
  self.login('Management Viewer');self.assertFalse(self.p.evaluate('E15.allowed("edit")'));self.p.evaluate('render("requests")');self.assertEqual(self.p.locator('[data-v15="new-request"]').count(),0)
  self.login('Authorized Event Requester');self.assertFalse(self.p.evaluate('E15.allowed("review")'));self.assertTrue(self.p.evaluate('E15.allowed("request")'))
  self.login('Supporting Department');self.p.evaluate('sessionStorage.setItem("emuDepartment","IT")');self.assertTrue(self.p.evaluate('()=>{try{E15.approval(15101,"Approved","Not my department");return false}catch(e){return true}}'))
  self.login('unknown');self.assertFalse(self.p.evaluate('E15.allowed("edit")'))
 def test_partner_statuses_import_preview_and_id_preservation(self):
  self.login();result=self.p.evaluate('()=>{const p=state.partners.find(p=>p.id===3),row=[p.name,"فئة تجريبية","نشاط تجريبي","+19995550123","Demo person","demo@example.invalid","مشاركة سابقة","ملاحظة جديدة"];const preview=E15.previewPartnerCSV([["Partner","Category","Activity","Phone","Contact Person","Email","Previous Participation","Notes"],row],"");return {matched:preview.rows[0].id,errors:preview.errors.length,status:preview.rows[0].values.relationshipStatus??null,has12:state.partners.some(p=>p.id===12)}}');self.assertEqual(result,{'matched':3,'errors':0,'status':None,'has12':True})
 def test_partner_csv_ui_confirmation_preserves_history_and_blank_contacts(self):
  self.login();self.p.evaluate('()=>{const p=state.partners.find(p=>p.id===3);p.phone="+19995550123";p.notes="Historical note";p.history=[{note:"Earlier follow-up"}];render("partners");E15.handlers["partner-import"]()}')
  name=self.p.evaluate('state.partners.find(p=>p.id===3).name')
  content='Partner,Category,Activity,Phone,Contact Person,Email,Previous Participation,Notes\n'+name+',فئة تجريبية,نشاط تجريبي,,,,مشاركة سابقة,New note\n'
  self.p.locator('#partnerCSV').set_input_files({'name':'synthetic.csv','mimeType':'text/csv','buffer':content.encode()})
  self.p.wait_for_function('E15.partnerImport?.rows.length===1')
  self.assertEqual(self.p.evaluate('state.partners.find(p=>p.id===3).notes'),'Historical note')
  self.p.once('dialog',lambda d:d.accept());self.p.locator('#applyPartnerCSV').click()
  actual=self.p.evaluate('()=>{const p=state.partners.find(p=>p.id===3);return {phone:p.phone,notes:p.notes,history:p.history.length,count:state.partners.length,has12:state.partners.some(p=>p.id===12)}}')
  self.assertEqual(actual,{'phone':'+19995550123','notes':'Historical note\n\nNew note','history':1,'count':21,'has12':True})
  self.p.evaluate('E15.handlers["partner-import"]()');self.p.locator('#partnerCSV').set_input_files({'name':'synthetic.csv','mimeType':'text/csv','buffer':content.encode()});self.p.wait_for_function('E15.partnerImport?.rows[0]?.unchanged===true')
  self.assertIn('Matched updates: 0',self.p.locator('#importPreview').inner_text())
 def test_file_storage_and_actual_download(self):
  self.login();meta=self.p.evaluate('async()=>await E15.files.put(new File(["sample bytes"],"demo.txt",{type:"text/plain"}))')
  with self.p.expect_download() as dl:self.p.evaluate('(id)=>E15.handlers.file(id)',meta['id'])
  self.assertEqual(Path(dl.value.path()).read_text(),'sample bytes')
 def test_marketing_finance_and_hours_guards(self):
  self.login();result=self.p.evaluate('()=>{const result={};for(const [key,c,v] of [["marketing","designs",{type:"Poster",published:true}],["finance","expenses",{item:"Test",amount:100,status:"Purchased"}],["hours","volunteers",{name:"Demo",hours:2,approvedHours:3}]])try{E15.record.save(c,{eventId:15001,...v});result[key]=false}catch(e){result[key]=true}return result}');self.assertEqual(result,{'marketing':True,'finance':True,'hours':True})
 def test_unique_ids_audit_and_calendar_source_dates(self):
  item=self.approved();self.assertTrue(self.p.evaluate('Object.values(state).filter(Array.isArray).every(rows=>new Set(rows.map(r=>r.id)).size===rows.length)'))
  self.assertTrue(self.p.evaluate('state.log.some(l=>l.before&&l.after&&l.actor&&l.reason)'))
  self.assertEqual(self.p.evaluate('state.events.find(e=>e.id===107).date'),'')
  self.assertEqual(self.p.evaluate('state.events.find(e=>e.id===110).date'),'2027-01-26')
 def test_settings_crud_exports_and_snapshot_validation(self):
  self.login();self.p.evaluate('render("settings")');self.p.locator('[data-v15="settings-venue-new"]').click();self.p.locator('#f-name').fill('Demo new room');self.p.locator('#f-capacity').fill('20');self.p.locator('#v15Save').click();self.assertTrue(self.p.evaluate('state.settings.venues.some(v=>v.name==="Demo new room")'))
  self.assertTrue(self.p.evaluate('()=>{try{E15.validateSnapshot({events:[]});return false}catch(e){return true}}'))
  self.p.evaluate('render("insights")')
  with self.p.expect_download() as dl:self.p.locator('[data-v15="insights-export"]').click()
  self.assertTrue(Path(dl.value.path()).read_bytes().startswith(b'PK'))
 def test_ui_manager_decision_legacy_requests_and_workspace(self):
  self.login()
  self.p.evaluate('render("requests")')
  self.p.locator('[data-v15="request"][data-id="ER-2026-014"]').click()
  self.assertTrue(self.p.locator('#modal').is_visible())
  self.p.keyboard.press('Escape')
  self.p.evaluate('E15.openWizard();E15.handlers["wizard-demo"]();E15.wizard.step=13;E15.drawWizard()')
  self.p.locator('#w-acknowledged').check();self.p.locator('[data-v15="wizard-submit"]').click()
  rid=self.p.evaluate('state.requests[0].id')
  self.p.locator(f'[data-v15="request"][data-id="{rid}"]').click()
  self.p.locator('[data-v15="review-request"]').click()
  self.p.locator('#f-decision').select_option('Under Review');self.p.locator('#f-reason').fill('Review started');self.p.locator('#v15Save').click()
  self.assertEqual(self.p.evaluate('state.requests[0].workflowStatus'),'Under Review')
  self.p.locator(f'[data-v15="request"][data-id="{rid}"]').click();self.p.locator('[data-v15="review-request"]').click();self.p.locator('#f-decision').select_option('Approved');self.p.locator('#f-reason').fill('Director approved');self.p.locator('#v15Save').click()
  self.p.locator('[data-v15="workspace"]').first.click();self.assertEqual(self.p.locator('[role="tab"]').count(),11)
  self.assertEqual(self.p.evaluate('state.requests[0].workflowStatus'),'Approved')
 def test_resource_forms_create_real_linked_records(self):
  self.login()
  cases={'tasks':{'titleAr':'مهمة تجريبية','owner':'Demo owner','due':'2027-05-01'},'reservations':{'date':'2027-07-01','setupTime':'09:00','startTime':'10:00','endTime':'12:00','breakdownTime':'13:00'},'volunteers':{'name':'Demo volunteer','shift':'10:00–12:00','hours':'2','approvedHours':'0'},'operations':{'owner':'Demo coordinator'},'expenses':{'item':'Demo purchase','amount':'120'},'designs':{'contentAr':'محتوى تجريبي'},'postReports':{'achievements':'إنجازات تجريبية','challenges':'تحديات تجريبية','recommendations':'توصيات تجريبية','satisfaction':'4'},'users':{'name':'Demo user','email':'user@example.invalid'}}
  for collection,fields in cases.items():
   with self.subTest(collection=collection):
    before=self.p.evaluate('(c)=>state[c].length',collection)
    self.p.evaluate('(c)=>E15.openRecord(c)',collection)
    if self.p.locator('#f-eventId').count():self.p.locator('#f-eventId').select_option('101' if collection=='postReports' else '15001')
    for key,value in fields.items():self.p.locator('#f-'+key).fill(value)
    self.p.locator('#v15Save').click()
    self.assertTrue(self.p.locator('#modal').get_attribute('class').find('hidden')>=0,self.p.locator('#formErrors').inner_text())
    self.assertEqual(self.p.evaluate('(c)=>state[c].length',collection),before+1)
 def test_excel_certificate_import_and_photo_report(self):
  self.login()
  data=self.p.evaluate('()=>{const b=XLSX.utils.book_new();XLSX.utils.book_append_sheet(b,XLSX.utils.json_to_sheet([{"Arabic Name":"مشارك تجريبي","English Name":"Demo Participant"}]),"Names");return Array.from(new Uint8Array(XLSX.write(b,{type:"array",bookType:"xlsx"}))) }')
  self.p.evaluate('E15.openWizard();E15.wizard.step=11;E15.drawWizard()')
  self.p.locator('#certificateImport').set_input_files({'name':'demo.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':bytes(data)})
  self.p.wait_for_function('E15.wizard.details.certificates?.length===1')
  self.assertEqual(self.p.evaluate('E15.wizard.details.certificates[0].nameAr'),'مشارك تجريبي')
  self.p.keyboard.press('Escape')
  self.p.evaluate('E15.openReport(15001)');self.assertIn('Formal English Report',self.p.locator('#formalReport').inner_text())
 def test_corrupt_storage_and_recovery_preserves_original(self):
  self.p.evaluate('localStorage.setItem("emuV15","{broken")');self.p.reload()
  self.assertTrue(self.p.locator('#storageNotice').is_visible());self.assertEqual(self.p.evaluate('localStorage.getItem("emuV15")'),'{broken')
 def test_requester_cannot_review_or_edit_other_owners(self):
  self.login();rid=self.p.evaluate('(d)=>E15.request.save(d,null,false).id',self.details())
  self.login('Authorized Event Requester');self.p.evaluate('sessionStorage.setItem("emuEmail","another@example.invalid")')
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.request.save({},id,false);return false}catch(e){return true}}',rid))
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.request.review(id,"Approved","Unauthorized");return false}catch(e){return true}}',rid))
 def test_calendar_filters_exports_and_legacy_approved_conversion(self):
  self.login();self.p.evaluate('render("calendar")');self.p.locator('#annualYear').select_option('2027');self.p.locator('#annualMode').select_option('list')
  self.assertNotIn('Annual Career Fair',self.p.locator('#content').inner_text()) # Approval alone no longer publishes calendar records.
  self.p.evaluate('E15.filter.calendar.search="zzzz";render("calendar")');self.assertEqual(self.p.evaluate('E15.calendarRows().length'),0)
  self.p.evaluate('render("requests");E15.reviewRequest("ER-2026-012")');self.p.locator('[data-v15="legacy-workspace"]').click()
  eid=self.p.evaluate('E15.activeEvent');self.assertTrue(eid)
  self.p.evaluate('E15.reviewRequest("ER-2026-012")');self.p.locator('[data-v15="workspace-modal"]').click();self.assertEqual(self.p.evaluate('E15.activeEvent'),eid)
 def test_logo_integrity_and_public_demo_privacy(self):
  expected={'EMU Logo BLUE.png':'f317c59a09b92bb644c1287cea8b118dc1c2e5885eb39d809c15334a71c36f89','EMU Logo.png':'715a1c9ddd7269f3dca0849136cc6416ebeaec0db021800b40db339ff11a4e61'}
  for name,digest in expected.items():self.assertEqual(hashlib.sha256((ROOT/'assets'/'branding'/name).read_bytes()).hexdigest(),digest)
  self.assertTrue(self.p.evaluate('SEED.partners.every(p=>!["phone","email","contactPerson","notes","history","relationshipStatus","sponsorshipStatus"].some(k=>k in p))'))
  self.login();self.p.evaluate('render("postreports");E15.openReport(15001)');self.p.emulate_media(media='print');self.assertTrue(self.p.locator('.report-identity .emu-logo--navy').count())
 def test_high_incident_blocks_readiness_and_report_draft_does_not_close(self):
  self.login()
  result=self.p.evaluate('()=>{const e=E15.entity("events",15001);for(const a of state.approvals.filter(a=>a.eventId===e.id))a.status="Approved";for(const t of state.tasks.filter(t=>t.eventId===e.id))t.status="Done";for(const r of state.reservations.filter(r=>r.eventId===e.id))r.status="Confirmed";for(const o of state.operations.filter(o=>o.eventId===e.id)){o.status="Done";o.resolved=true}const safety=state.operations.find(o=>o.eventId===e.id&&o.severity==="High");safety.resolved=false;const blocked=E15.readiness(e.id)<100;safety.resolved=true;e.lifecycle="Post-Event Reporting";let draftBlocked=false;try{E15.stage(e.id,"Closed")}catch(error){draftBlocked=true}return {blocked,draftBlocked}}')
  self.assertEqual(result,{'blocked':True,'draftBlocked':True})
 def test_local_qr_registration_route_and_calendar_year_boundary(self):
  self.p.goto(self.url+'?register=15001')
  self.assertEqual(self.p.locator('#loginRole').input_value(),'Authorized Event Requester')
  self.p.locator('#loginRole').select_option('EMU Staff');self.p.locator('#signIn').click()
  self.assertEqual(self.p.evaluate('page'),'attendance')
  self.login();self.p.evaluate('calendarYear=2026;calendarMonth=11;E15.filter.calendar={year:"2026"};render("calendar");setMonth(1)')
  self.assertEqual(self.p.locator('#annualYear').input_value(),'2027')
 def test_status_and_reference_mutation_guards(self):
  self.login();eid=self.approved()['eventId']
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.record.save("events",{reference:"REPLACED"},id);return false}catch(e){return true}}',eid))
  self.assertTrue(self.p.evaluate('(id)=>{try{const c=E15.change.request(id,"campus","Invalid Campus","Demo reason","Demo impact");E15.change.review(c.id,true,"Decision");return false}catch(e){return true}}',eid))
 def test_event_date_reference_format_sequence_and_first_submission(self):
  self.login();result=self.p.evaluate('(d)=>{const draft=E15.request.save(d,null,false);const unnumbered=!draft.reference;d.date="2026-10-14";d.workshops=[];const a=E15.request.save(d,draft.id,true),b=E15.request.save(d,null,true);const c=E15.request.save({...d,date:"2026-10-15"},null,true);E15.request.review(a.id,"Rejected","Revise");const retry=E15.request.save({...d,date:"2026-10-20"},a.id,true);return {unnumbered,a:a.reference,b:b.reference,c:c.reference,retry:retry.reference}}',self.details())
  self.assertEqual(result,{'unnumbered':True,'a':'EMU141026-001','b':'EMU141026-002','c':'EMU151026-001','retry':'EMU141026-001'})
 def test_reference_collision_recovery_persisted_counter_and_stale_store(self):
  self.login();result=self.p.evaluate('(d)=>{d.workshops=[];d.date="2026-10-14";state.referenceCounters={};state.events.push({...state.events[0],id:17001,reference:"EMU141026-005"});const a=E15.request.save(d,null,true);state.requests=state.requests.filter(r=>r.id!==a.id);E15.commit();return a.reference}',self.details());self.assertEqual(result,'EMU141026-006')
  self.p.reload();self.assertEqual(self.p.evaluate('(d)=>{d.workshops=[];d.date="2026-10-14";return E15.request.save(d,null,true).reference}',self.details()),'EMU141026-007')
  self.assertTrue(self.p.evaluate('(d)=>{const raw=localStorage.getItem("emuV15");localStorage.setItem("emuV15",raw+" ");try{E15.request.save(d,null,true);return false}catch(e){return true}}',self.details()))
 def test_reference_capacity_and_invalid_date_rollback(self):
  self.login();result=self.p.evaluate('(d)=>{d.date="2026-10-14";d.workshops=[];state.referenceCounters["EMU141026-"]=999;const before=JSON.stringify(state);let exhausted=false,invalid=false;try{E15.request.save(d,null,true)}catch(e){exhausted=e.message.includes("999")}const rolledBack=JSON.stringify(state)===before;try{E15.reference("2026-02-30")}catch(e){invalid=true}return {exhausted,rolledBack,invalid}}',self.details());self.assertEqual(result,{'exhausted':True,'rolledBack':True,'invalid':True})
 def test_reference_visible_across_required_modules_in_both_languages(self):
  item=self.approved();eid=item['eventId'];ref=item['reference']
  self.p.evaluate('(id)=>{for(const a of state.approvals.filter(a=>a.eventId===id&&a.dept==="Marketing"))E15.approval(a.id,"Approved","Ready");E15.publication.request(id);E15.publication.review(id,"Approved","Public calendar approved")}',eid)
  for language in ['ar','en']:
   self.p.evaluate('(l)=>{lang=l;init()}',language)
   for module in ['requests','events','tasks','calendar','attendance','postreports','log']:
    self.p.evaluate('([m,id])=>{calendarYear=2027;calendarMonth=4;E15.filter.calendar={year:"2027",mode:"month"};E15.filter.attendance={eventId:String(id)};render(m)}',[module,eid])
    self.assertIn(ref,self.p.locator('#content').inner_text(),module+' '+language)
   self.p.evaluate('(id)=>E15.handlers.workspace(id)',eid);self.assertIn(ref,self.p.locator('#content').inner_text())
   self.p.evaluate('render("requests")');self.p.locator('#moduleSearch').fill(ref);self.assertIn(ref,self.p.locator('#content').inner_text())
  self.assertFalse(self.p.evaluate('!!document.querySelector("input[name=reference],input#reference")'))
 def test_reference_survives_approved_date_change_and_reload(self):
  item=self.approved();eid=item['eventId'];self.assertEqual(item['reference'],'EMU120527-001')
  self.p.evaluate('(id)=>{const c=E15.change.request(id,"date","2027-05-13","New date","Recheck venue");E15.change.review(c.id,true,"Approved")}',eid)
  self.p.reload();self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).reference',eid),item['reference'])
  result=self.p.evaluate('(d)=>{const a=E15.request.save(d,null,true);return [a.reference,E15.request.save({...d,date:"2027-05-13",workshops:[]},null,true).reference]}',self.details());self.assertEqual(result,['EMU120527-002','EMU130527-001'])
 def test_director_publication_is_a_separate_approval_with_history(self):
  item=self.approved();eid=item['eventId'];self.assertFalse(self.p.evaluate('(id)=>E15.entity("events",id).published',eid))
  result=self.p.evaluate('(id)=>{E15.publication.request(id);let blocked=false;try{E15.publication.review(id,"Approved","Publish")}catch(e){blocked=true}const a=state.approvals.find(a=>a.eventId===id&&a.dept==="Marketing");E15.approval(a.id,"Approved","Marketing ready");return {blocked,published:E15.entity("events",id).published,status:E15.entity("events",id).calendarPublication.status}}',eid);self.assertEqual(result,{'blocked':True,'published':False,'status':'Pending'})
  self.p.evaluate('render("tasks")');self.p.locator(f'[data-v15="publication-review"][data-id="{eid}"]').click();self.p.locator('#f-reason').fill('Independent publication approval');self.p.locator('#v15Save').click()
  self.assertTrue(self.p.evaluate('(id)=>E15.entity("events",id).published',eid))
  self.p.evaluate('(id)=>{const c=E15.change.request(id,"date","2027-05-13","Reschedule","Calendar needs review");E15.change.review(c.id,true,"Date approved")}',eid)
  result=self.p.evaluate('(id)=>{const e=E15.entity("events",id);return {published:e.published,status:e.calendarPublication.status,reference:e.reference,history:e.calendarPublication.history.length}}',eid);self.assertEqual(result,{'published':False,'status':'Needs Review','reference':item['reference'],'history':3})
  self.p.reload();self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).calendarPublication.status',eid),'Needs Review')
 def test_director_publication_rejection_withdrawal_and_role_guards(self):
  item=self.approved();eid=item['eventId'];self.p.evaluate('(id)=>{E15.publication.request(id);E15.publication.review(id,"Rejected","Not ready");E15.publication.request(id);E15.publication.withdraw(id)}',eid)
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).calendarPublication.status',eid),'Withdrawn')
  self.login('EMU Staff');self.p.evaluate('(id)=>E15.publication.request(id)',eid);self.assertTrue(self.p.evaluate('(id)=>{try{E15.publication.review(id,"Approved","Unauthorized");return false}catch(e){return true}}',eid))
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.record.save("events",{published:true},id);return false}catch(e){return true}}',eid))
 def test_director_linked_metrics_and_normalized_duplicate_attendance(self):
  self.login();result=self.p.evaluate('()=>{const e=E15.entity("events",15001),before=E15.reportTotals(e.id);E15.record.save("events",{partners:[3,12]},e.id);const row=E15.attendance.register(e.id,{name:"Synthetic director guest",email:"DIRECTOR@example.invalid"});const registered=E15.reportTotals(e.id);let duplicate=false;try{E15.attendance.register(e.id,{name:"Repeated",email:" director@example.invalid "})}catch(error){duplicate=true}E15.attendance.checkin(row.id);const after=E15.reportTotals(e.id);return {duplicate,registeredDelta:registered.registered-before.registered,attendedBeforeCheckin:registered.attendance-before.attendance,attendedAfter:after.attendance-before.attendance,partners:after.partners,relationshipIDs:e.partners}}');self.assertEqual(result,{'duplicate':True,'registeredDelta':1,'attendedBeforeCheckin':0,'attendedAfter':1,'partners':2,'relationshipIDs':[3,12]})
  self.p.evaluate('E15.handlers.workspace(15001);E15.workspaceTab="attendance";render("workspace")');self.assertIn('Attendance',self.p.locator('#content').inner_text());self.p.evaluate('E15.openReport(15001)');metrics=self.p.locator('#formalReport .report-metrics>div').evaluate_all('(rows)=>Object.fromEntries(rows.map(r=>[r.querySelector("span").textContent,r.querySelector("b").textContent]))');self.assertEqual({key:metrics[key] for key in ['Registrations','Attendance','Partners']},{'Registrations':'2','Attendance':'1','Partners':'2'});self.p.keyboard.press('Escape');self.p.evaluate('render("insights")');self.assertEqual(self.p.locator('[data-kpi=attendance]>b').inner_text(),'1')
 def test_director_approved_details_cannot_bypass_change_workflow(self):
  item=self.approved();eid=item['eventId'];result=self.p.evaluate('(id)=>["date","time","setupTime","category","orgEn","status","lifecycle","sourceRequestId"].every(k=>{try{E15.record.save("events",{[k]:"BYPASS"},id);return false}catch(e){return true}})',eid);self.assertTrue(result)
 def test_private_partner_backup_ui_then_csv_retains_id12_and_relationships(self):
  self.login();backup=self.p.evaluate('()=>({partners:state.partners.map(p=>({...structuredClone(p),phone:p.phone||"",email:p.email||"",contactPerson:p.contactPerson||"",notes:p.notes||"",history:p.history||[]}))})');backup['partners'][2]['name']='Synthetic original partner 3';backup['partners'][2]['history']=[{'date':'2026-10-01','channel':'Email','note':'Synthetic previous follow-up'}];backup['partners'][11]['name']='Synthetic unmatched partner 12'
  links=self.p.evaluate('state.events.map(e=>({id:e.id,partners:e.partners}))');self.p.evaluate('E15.handlers["partner-import"]()')
  self.p.once('dialog',lambda d:d.accept());self.p.locator('#privatePartnerBaseline').set_input_files({'name':'synthetic.private.json','mimeType':'application/json','buffer':json.dumps(backup).encode()});self.p.wait_for_function('state.privatePartnersLoaded===true')
  content='Partner,Category,Activity,Phone,Contact Person,Email,Previous Participation,Notes\nSynthetic original partner 3,فئة خاصة تجريبية,نشاط تجريبي,+1 (999) 555-0123,Demo contact,demo@example.invalid,مشاركة سابقة,New synthetic note\n'
  self.p.locator('#partnerCSV').set_input_files({'name':'synthetic.csv','mimeType':'text/csv','buffer':content.encode()});self.p.wait_for_function('E15.partnerImport?.rows.length===1');self.assertEqual(self.p.evaluate('E15.partnerImport.errors'),[])
  self.p.once('dialog',lambda d:d.accept());self.p.locator('#applyPartnerCSV').click();self.assertEqual(self.p.locator('tr[data-id]').count(),21)
  actual=self.p.evaluate('()=>({p:state.partners.find(p=>p.id===3),p12:state.partners.find(p=>p.id===12),links:state.events.map(e=>({id:e.id,partners:e.partners}))})');self.assertEqual(actual['p']['phone'],'+1 (999) 555-0123');self.assertEqual(actual['p']['history'],backup['partners'][2]['history']);self.assertEqual({k:v for k,v in actual['p12'].items() if k!='privateAvailable'},{k:v for k,v in backup['partners'][11].items() if k!='privateAvailable'});self.assertEqual(actual['links'],links)
  self.p.reload();self.p.evaluate('render("partners")');self.p.locator('#partnerSearch').fill('Synthetic original partner 3');self.assertEqual(self.p.locator('tr[data-id]').count(),1)
 def test_booths_terminology_in_both_languages(self):
  self.login();self.p.evaluate('E15.openWizard();E15.wizard.step=4;E15.drawWizard()')
  self.assertNotIn('الأجنحة',self.p.locator('#modal').inner_text())
  self.assertEqual(self.p.evaluate('()=>{lang="ar";return [E15.t("Booths"),E15.t("University Booths"),E15.t("External Booths")]}'),['الأركان','الأركان الجامعية','أركان الجهات الخارجية'])
  self.assertEqual(self.p.evaluate('()=>{lang="en";return E15.t("University Pop-up Booths")}'),'University Booths')
 def test_qr_png_independently_decoded_for_every_approved_event(self):
  import sys,io
  if os.environ.get('QR_DECODER_PATH'):sys.path.insert(0,os.environ['QR_DECODER_PATH'])
  try:
   import zxingcpp
   from PIL import Image
  except ImportError:self.skipTest('Install zxing-cpp and Pillow for independent image decoding')
  self.login();events=self.p.evaluate('state.events.filter(E15.isApproved).map(e=>({id:e.id,url:E15.registrationURL(e)}))');decoded=[]
  for e in events:
   self.p.evaluate('(id)=>{E15.filter.attendance={eventId:String(id)};render("attendance")}',e['id'])
   with self.p.expect_download() as dl:self.p.locator('[data-v15="qr-png"]').click()
   png=Path(dl.value.path()).read_bytes();self.assertTrue(png.startswith(b"\x89PNG\r\n\x1a\n"));result=zxingcpp.read_barcode(Image.open(io.BytesIO(png)));self.assertIsNotNone(result);self.assertEqual(result.text,e['url']);decoded.append(result.text)
   self.p.goto(result.text);self.assertEqual(self.p.evaluate('page'),'attendance');self.assertEqual(self.p.locator('#moduleEvent').input_value(),str(e['id']))
   self.p.locator('[data-v15="attendance-windows"]').click();today=self.p.evaluate('todayISO()')
   for key,hour in [('registrationOpen','00:00'),('registrationClose','23:59'),('checkinOpen','00:00'),('checkinClose','23:59')]:self.p.locator('#f-'+key).fill(today+'T'+hour)
   self.p.locator('#v15Save').click();before=self.p.evaluate('(id)=>E15.reportTotals(id)',e['id']);email=f'qr-{e["id"]}@example.invalid'
   self.p.locator('[data-v15="register"]').click();self.p.locator('#f-name').fill('Decoded QR demo guest');self.p.locator('#f-email').fill(email);self.p.locator('#v15Save').click();aid=self.p.evaluate('(email)=>state.registrations.find(a=>a.email===email).id',email)
   self.assertEqual(self.p.evaluate('(id)=>E15.reportTotals(id).registered',e['id']),before['registered']+1);self.p.locator(f'[data-v15="checkin"][data-id="{aid}"]').click();self.assertEqual(self.p.evaluate('(id)=>E15.reportTotals(id).attendance',e['id']),before['attendance']+1)
   self.assertTrue(self.p.evaluate('(id)=>{try{E15.attendance.checkin(id);return false}catch(e){return true}}',aid))
   with self.p.expect_download() as exported:self.p.locator('[data-v15="attendance-export"]').click()
   self.assertIn(email,Path(exported.value.path()).read_text(encoding='utf-8-sig'))
  self.assertEqual(len(set(decoded)),len(events));self.assertGreater(len(events),1)
  self.p.goto(self.url+'?register=99999999');self.assertIn('unavailable',self.p.locator('#content').inner_text());self.assertEqual(self.p.locator('[data-v15=register]').count(),0)
 def test_rbac_staff_default_denials_and_independent_delegation(self):
  item=self.approved();eid=item['eventId'];rid=self.p.evaluate('(d)=>E15.request.save({...d,date:"2027-06-12",workshops:[]},null,true).id',self.details())
  self.p.evaluate('E15.auth.switchIdentity(700003)')
  self.assertEqual(self.p.evaluate('Object.keys(E15.accessPolicy.approvalPermissions).map(k=>E15.allowed(k))'),[False,False,False])
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.request.review(id,"Approved","Staff default");return false}catch(e){return true}}',rid))
  self.assertTrue(self.p.evaluate('()=>{try{E15.auth.delegate(700004,"reviewEvent",true);return false}catch(e){return true}}'))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.delegate(700003,"reviewEvent",true);E15.auth.switchIdentity(700003)')
  actor=self.p.evaluate('(id)=>E15.request.review(id,"Approved","Delegated decision").decisions.at(-1).actor',rid);self.assertEqual(actor['approvalAuthority'],'Delegated EMU Staff');self.assertEqual(actor['permission'],'reviewEvent');self.assertEqual(actor['delegatedBy'],700002)
  self.assertFalse(self.p.evaluate('E15.allowed("reviewChange")'));self.assertFalse(self.p.evaluate('E15.allowed("reviewPublication")'))
  cid=self.p.evaluate('(id)=>E15.change.request(id,"titleEn","Delegated revision","Demo change","No timing change").id',eid)
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.change.review(id,true,"Not delegated");return false}catch(e){return true}}',cid))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.delegate(700003,"reviewChange",true);E15.auth.switchIdentity(700003)');self.p.evaluate('(id)=>E15.change.review(id,true,"Delegated change")',cid)
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("changes",id).reviewedBy.approvalAuthority',cid),'Delegated EMU Staff')
  self.p.evaluate('(id)=>{E15.auth.switchIdentity(700002);E15.approval(state.approvals.find(a=>a.eventId===id&&a.dept==="Marketing").id,"Approved","Ready");E15.publication.request(id);E15.auth.delegate(700003,"reviewPublication",true);E15.auth.switchIdentity(700003);E15.publication.review(id,"Approved","Separate delegated decision")}',eid)
  self.assertEqual(self.p.evaluate('(id)=>E15.entity("events",id).calendarPublication.history.at(-1).actor.permission',eid),'reviewPublication')
 def test_rbac_revocation_expiration_and_nonstaff_target(self):
  self.login();self.assertTrue(self.p.evaluate('()=>{try{E15.auth.delegate(700001,"reviewEvent",true);return false}catch(e){return true}}'))
  self.p.evaluate('E15.auth.delegate(700003,"reviewEvent",true);E15.auth.delegate(700003,"reviewEvent",false);E15.auth.switchIdentity(700003)');self.assertFalse(self.p.evaluate('E15.allowed("reviewEvent")'))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.delegate(700003,"reviewChange",true);state.users.find(u=>u.id===700003).delegations.reviewChange.expiresAt="2000-01-01";E15.auth.switchIdentity(700003)');self.assertFalse(self.p.evaluate('E15.allowed("reviewChange")'))
  self.p.evaluate('render("access")');self.assertIn('Not delegated',self.p.locator('#content').inner_text());self.assertTrue(self.p.evaluate('state.log.some(l=>l.action==="Delegation revoked"&&l.before&&l.after&&l.actor)'))
 def test_rbac_requester_registry_ownership_and_revocation(self):
  self.login();other=self.p.evaluate('(d)=>E15.request.save(d,null,true).id',self.details());self.p.evaluate('E15.auth.switchIdentity(700005)');own=self.p.evaluate('(d)=>E15.request.save(d,null,false).id',self.details())
  visible=self.p.evaluate('async()=>await E15.api.list("requests")');self.assertEqual([r['id'] for r in visible],[own]);self.assertTrue(self.p.evaluate('(id)=>{try{E15.entity("requests",id);return false}catch(e){return true}}',other))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.saveUser({requestAuthorized:false},700005);E15.auth.switchIdentity(700005)');self.assertFalse(self.p.evaluate('E15.allowed("request")'));self.assertTrue(self.p.evaluate('(d)=>{try{E15.request.save(d,null,true);return false}catch(e){return true}}',self.details()));self.assertEqual(len(self.p.evaluate('async()=>await E15.api.list("requests")')),1)
  self.p.evaluate('sessionStorage.setItem("emuEmail","unlisted@example.invalid");init()');self.assertFalse(self.p.evaluate('E15.allowed("request")'));self.assertIn('Access denied',self.p.locator('#content').inner_text())
 def test_rbac_department_scope_and_own_change_authority(self):
  item=self.approved();eid=item['eventId'];self.p.evaluate('(id)=>{E15.record.save("tasks",{eventId:id,titleEn:"IT assigned",titleAr:"مهمة",dept:"IT",owner:"IT",due:"2027-05-01",priority:"High",status:"Pending"});E15.record.save("tasks",{eventId:id,titleEn:"Confidential Marketing task",titleAr:"مهمة خاصة",dept:"Marketing",owner:"Marketing",due:"2027-05-01",priority:"High",status:"Pending"});E15.auth.switchIdentity(700006);render("tasks")}',eid)
  self.assertIn('IT assigned',self.p.locator('#content').inner_text());self.assertNotIn('Confidential Marketing task',self.p.locator('#content').inner_text());self.assertTrue(all(t['dept']=='IT' for t in self.p.evaluate('async()=>await E15.api.list("tasks")')))
  self.assertTrue(self.p.evaluate('(id)=>{try{E15.record.save("tasks",{eventId:id,dept:"Marketing",titleEn:"Bypass",due:"2027-05-01",priority:"High",status:"Pending"});return false}catch(e){return true}}',eid))
  self.p.evaluate('E15.auth.switchIdentity(700005)');self.assertTrue(self.p.evaluate('(id)=>{try{E15.change.request(id,"titleEn","Unauthorized","Reason","Impact");return false}catch(e){return true}}',eid))
 def test_rbac_sponsor_routes_exports_and_views_do_not_expose_contacts(self):
  item=self.approved();eid=item['eventId'];self.p.evaluate('()=>{const p=state.partners[0];p.name="CONFIDENTIAL_PARTNER_SENTINEL";p.phone="+19995550999";p.email="confidential@example.invalid";E15.commit()}')
  for uid in [700001,700005,700006,700007]:
   self.p.evaluate('(id)=>E15.auth.switchIdentity(id)',uid);self.assertEqual(self.p.locator('.nav [data-page="partners"]').count(),0);self.p.evaluate('render("partners")');self.assertIn('Access denied',self.p.locator('#content').inner_text());self.assertEqual(self.p.evaluate('async()=>await E15.api.list("partners")'),[])
   self.assertTrue(self.p.evaluate('()=>{try{exportPartners();return false}catch(e){return true}}'));self.assertTrue(self.p.evaluate('()=>{try{E15.handlers["dataset-export"]();return false}catch(e){return true}}'))
   for module in ['dashboard','events','calendar','insights','postreports']:
    self.p.evaluate('(m)=>render(m)',module);body=self.p.locator('#content').inner_text();self.assertNotIn('CONFIDENTIAL_PARTNER_SENTINEL',body);self.assertNotIn('confidential@example.invalid',body);self.assertNotIn('+19995550999',body)
   self.p.evaluate('(id)=>{E15.activeEvent=id;E15.workspaceTab="guests";render("workspace")}',eid);self.assertNotIn('CONFIDENTIAL_PARTNER_SENTINEL',self.p.locator('#content').inner_text())
 def test_rbac_director_and_staff_sponsors_technical_admin_separation(self):
  self.login();self.p.evaluate('render("partners")');self.assertEqual(self.p.locator('tr[data-id]').count(),21)
  self.p.evaluate('E15.auth.switchIdentity(700003);render("partners")');self.assertEqual(self.p.locator('tr[data-id]').count(),21)
  self.p.evaluate('E15.auth.switchIdentity(700001);render("settings")');self.assertIn('Integration readiness',self.p.locator('#content').inner_text());self.assertEqual(self.p.locator('#datasetImport').count(),0);self.assertEqual(self.p.locator('[data-v15="dataset-export"]').count(),0);self.assertFalse(self.p.evaluate('E15.allowed("reviewEvent")'));self.assertFalse(self.p.evaluate('E15.allowed("users")'))
 def test_rbac_users_ui_authorization_delegation_and_immediate_identity_switch(self):
  self.login();self.p.evaluate('render("access");E15.userDetails(700003)');self.p.locator('[data-grant="reviewEvent"]').check();self.p.locator('[data-save-grant="reviewEvent"]').click();self.p.keyboard.press('Escape');self.p.locator('#rolePreviewBtn').click();self.p.locator('[data-preview-id="700003"]').click();self.assertEqual(self.p.locator('#roleLabel').inner_text(),'EMU Staff');self.assertTrue(self.p.evaluate('E15.allowed("reviewEvent")'));self.assertFalse(self.p.evaluate('E15.allowed("reviewChange")'));self.p.evaluate('render("access")');self.assertIn('Delegated',self.p.locator('#content').inner_text())
  self.p.evaluate('E15.auth.switchIdentity(700002);render("access")');self.p.locator('[data-v15="access-add"]').click()
  for key,value in {'name':'Authorized UI requester','email':'authorized-ui@example.invalid','department':'Demo College'}.items():self.p.locator('#f-'+key).fill(value)
  self.p.locator('#v15Save').click();self.assertTrue(self.p.evaluate('state.users.some(u=>u.email==="authorized-ui@example.invalid"&&u.requestAuthorized===true)'))
 def test_rbac_role_navigation_bilingual_responsive_and_readonly(self):
  self.login()
  for language in ['ar','en']:
   for width in [1440,390]:
    self.p.set_viewport_size({'width':width,'height':1000})
    for uid in [700001,700002,700003,700004,700005,700006,700007]:
     self.p.evaluate('([uid,l])=>{lang=l;E15.auth.switchIdentity(uid)}',[uid,language]);self.assertLessEqual(self.p.evaluate('document.documentElement.scrollWidth-innerWidth'),1)
     for module in self.p.locator('.nav [data-page]').evaluate_all('(xs)=>xs.map(x=>x.dataset.page)'):
      self.p.evaluate('(m)=>render(m)',module);self.assertLessEqual(self.p.evaluate('document.documentElement.scrollWidth-innerWidth'),1,module+' '+str(uid)+' '+language)
  self.p.evaluate('E15.auth.switchIdentity(700007)');self.assertFalse(self.p.evaluate('E15.allowed("edit")'));self.assertEqual(self.p.locator('[data-v15="new-request"]').count(),0)
 def test_rbac_management_reports_require_explicit_share(self):
  self.login();self.p.evaluate('E15.auth.switchIdentity(700003)');self.assertTrue(self.p.evaluate('()=>{try{E15.record.save("postReports",{managementAuthorized:true},16101);return false}catch(e){return true}}'));self.p.evaluate('E15.auth.switchIdentity(700007)');self.assertTrue(self.p.evaluate('()=>{try{E15.openReport(15001);return false}catch(e){return true}}'))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.record.save("postReports",{eventId:15001,status:"Completed",managementAuthorized:true,achievements:"Demo",challenges:"Demo",recommendations:"Demo",satisfaction:4},16101);E15.auth.switchIdentity(700007);E15.openReport(15001)');self.assertIn('Formal English Report',self.p.locator('#formalReport').inner_text());self.assertEqual(self.p.locator('[data-v15="edit-report"]').count(),0)
 def test_rbac_unknown_and_inactive_identities_fail_closed(self):
  self.login();self.p.evaluate('E15.auth.saveUser({status:"Inactive"},700003);sessionStorage.setItem("emuRole","EMU Staff");sessionStorage.setItem("emuEmail","staff@example.invalid");init()');self.assertFalse(self.p.evaluate('E15.allowed("partners")'));self.assertIn('Access denied',self.p.locator('#content').inner_text())
  self.p.evaluate('sessionStorage.setItem("emuRole","unrecognized");init()');self.assertFalse(self.p.evaluate('E15.auth.route("events")'))
 def test_rbac_authorized_submission_own_change_and_staff_sponsor_toggle(self):
  self.login();self.p.evaluate('E15.auth.switchIdentity(700005)');rid=self.p.evaluate('(d)=>E15.request.save(d,null,true).id',self.details());self.assertEqual(self.p.evaluate('(id)=>E15.entity("requests",id).workflowStatus',rid),'Submitted')
  eid=self.p.evaluate('(id)=>{E15.auth.switchIdentity(700002);E15.request.review(id,"Approved","Director review");return E15.entity("requests",id).eventId}',rid);self.p.evaluate('E15.auth.switchIdentity(700005)');cid=self.p.evaluate('(id)=>E15.change.request(id,"titleEn","Requester revision","Owner feedback","No timing change").id',eid);self.assertTrue(cid)
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.staffPermission(700003,"partners",false);E15.auth.switchIdentity(700003);render("partners")');self.assertIn('Access denied',self.p.locator('#content').inner_text());self.assertFalse(self.p.evaluate('E15.allowed("partners")'));self.assertTrue(self.p.evaluate('()=>{try{E15.loadPrivatePartners({});return false}catch(e){return true}}'))
  self.p.evaluate('E15.auth.switchIdentity(700002);E15.auth.staffPermission(700003,"partners",true);E15.auth.switchIdentity(700003);render("partners")');self.assertEqual(self.p.locator('tr[data-id]').count(),21)
 def test_rbac_other_tab_revocation_removes_cached_authority(self):
  self.login();self.p.evaluate('E15.auth.delegate(700003,"reviewEvent",true);E15.auth.switchIdentity(700003)');self.assertTrue(self.p.evaluate('E15.allowed("reviewEvent")'))
  director=self.context.new_page();director.goto(self.url);director.evaluate('sessionStorage.setItem("emuLogin","1");sessionStorage.setItem("emuRole","EMU Director");sessionStorage.setItem("emuEmail","director@example.invalid");init();E15.auth.delegate(700003,"reviewEvent",false);E15.auth.staffPermission(700003,"partners",false)')
  self.p.wait_for_function('!E15.allowed("reviewEvent")&&!E15.allowed("partners")');self.assertEqual(self.p.locator('.nav [data-page="partners"]').count(),0);director.close()
 @unittest.skipUnless(os.environ.get('CAPTURE_SCREENSHOTS')=='1','Set CAPTURE_SCREENSHOTS=1')
 def test_screenshots(self):
  self.login();out=ROOT/'screenshots'/'v15';out.mkdir(exist_ok=True)
  for language in ['ar','en']:
   self.p.evaluate('(l)=>{lang=l;init()}',language);self.p.set_viewport_size({'width':1440,'height':1000})
   for module in MODULES:
    self.p.evaluate('(m)=>render(m)',module);self.p.screenshot(path=str(out/f'{module}-{language}.png'),full_page=True,animations='disabled')
   self.p.evaluate('E15.handlers.workspace(15001)');self.p.screenshot(path=str(out/f'workspace-{language}.png'),full_page=True,animations='disabled')
   self.p.evaluate('E15.openWizard();E15.handlers["wizard-demo"]();E15.wizard.step=1;E15.drawWizard()');self.p.screenshot(path=str(out/f'request-wizard-{language}.png'),animations='disabled');self.p.keyboard.press('Escape')
   self.p.evaluate('E15.openReport(15001);document.body.classList.add("printing-dialog")');self.p.emulate_media(media='print');self.p.screenshot(path=str(out/f'formal-report-{language}.png'),full_page=True,animations='disabled');self.p.emulate_media(media='screen');self.p.evaluate('document.body.classList.remove("printing-dialog");closeModal()')
   self.p.set_viewport_size({'width':390,'height':844})
   for module in ['dashboard','requests','attendance','partners','venues']:
    self.p.evaluate('(m)=>{setNav(false);render(m);scrollTo(0,0)}',module);self.p.screenshot(path=str(out/f'mobile-{module}-{language}.png'),animations='disabled')
   self.p.set_viewport_size({'width':1440,'height':1000});self.p.evaluate('E15.auth.switchIdentity(700002);render("access");E15.rolePreview()');self.p.screenshot(path=str(out/f'role-preview-{language}.png'),animations='disabled');self.p.keyboard.press('Escape')
   self.p.evaluate('E15.auth.switchIdentity(700003);render("access")');self.p.screenshot(path=str(out/f'staff-profile-{language}.png'),full_page=True,animations='disabled')
   self.p.evaluate('E15.auth.switchIdentity(700002);render("access")');self.p.set_viewport_size({'width':390,'height':844});self.p.screenshot(path=str(out/f'mobile-access-{language}.png'),animations='disabled')
if __name__=='__main__':unittest.main()
