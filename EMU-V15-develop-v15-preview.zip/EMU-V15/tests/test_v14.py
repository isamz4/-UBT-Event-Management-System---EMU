"""V14 browser regressions. Run: python3 -m unittest discover -s tests -v
Uses a disposable local server and fresh browser context for every test.
Set CAPTURE_SCREENSHOTS=1 to refresh the review screenshots.
"""
import functools
import http.server
import importlib.metadata
import json
import os
from pathlib import Path
import threading
import unittest
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PAGES = ['dashboard','events','calendar','requests','tasks','partners','reports','access','log']
WIDTHS = [1440,1024,768,390,320]

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

@unittest.skipIf('data-v15' in (ROOT/'index.html').read_text(), "V14 baseline suite: run on develop-v14; V15 has a separate workflow suite")
class V14Regression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(ROOT)))
        cls.thread = threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url = f'http://127.0.0.1:{cls.server.server_port}/'
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.context = self.browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        self.page = self.context.new_page()
        self.errors = []
        self.page.on('pageerror',lambda error:self.errors.append(str(error)))
        self.page.goto(self.url)

    def tearDown(self):
        self.context.close()
        self.assertEqual(self.errors,[], 'Unexpected JavaScript errors')

    def login(self, role='EMU Admin', lang='en'):
        self.page.evaluate('([r,l])=>{localStorage.setItem("emuLang",l);sessionStorage.setItem("emuLogin","1");sessionStorage.setItem("emuRole",r)}',[role,lang])
        self.page.reload()

    def render(self, target):
        self.page.evaluate('(p)=>render(p)',target)

    def test_arabic_default_login_and_language_persistence(self):
        self.assertEqual(self.page.locator('html').get_attribute('lang'),'ar')
        self.assertEqual(self.page.locator('html').get_attribute('dir'),'rtl')
        self.page.locator('#signIn').click()
        self.assertEqual(self.page.locator('#content').count(),0)
        self.page.locator('#loginEmail').fill('demo@ubt.edu.sa')
        self.page.locator('#signIn').click()
        self.assertEqual(self.page.locator('.nav [data-page]').count(),9)
        self.page.locator('#langBtn').click()
        self.page.reload()
        self.assertEqual(self.page.locator('html').get_attribute('lang'),'en')
        self.page.locator('#logout').click()
        self.assertEqual(self.page.locator('#loginForm').count(),1)

    def test_all_pages_bilingual_responsive_and_dialog_labels(self):
        self.login()
        for lang in ['ar','en']:
            self.page.evaluate('(l)=>{lang=l;init()}',lang)
            for width in WIDTHS:
                with self.subTest(language=lang,width=width):
                    self.page.set_viewport_size({'width':width,'height':1000})
                    for target in PAGES:
                        self.render(target)
                        self.assertTrue(self.page.locator('#content').inner_text().strip())
                        self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth-innerWidth'),1,target)
                        self.assertEqual(self.page.locator('table tbody tr[data-id]:not([tabindex="0"])').count(),0)
                    for action in ['eventModal(103)','requestModal("ER-2026-012")','taskModal(1)','approvalModal(201)','partnerModal(1)','followModal(1)']:
                        self.page.evaluate(action)
                        self.assertTrue(self.page.locator('#modal').is_visible())
                        self.assertEqual(self.page.locator('.modal-card').evaluate('(e)=>e.scrollWidth-e.clientWidth'),0)
                        self.assertEqual(self.page.locator('#modalForm input:not([type=checkbox]),#modalForm select,#modalForm textarea').evaluate_all('(els)=>els.filter(e=>!e.labels?.length&&!e.getAttribute("aria-label")).length'),0,action)
                        self.page.keyboard.press('Escape')
                    if width<=600:
                        self.render('calendar')
                        self.assertTrue(self.page.locator('.mobile-agenda').is_visible())
                        self.assertFalse(self.page.locator('.calendar').is_visible())

    def test_continuous_search_typing_and_selection(self):
        self.login()
        self.render('events')
        self.page.locator('#eventSearch').press_sequentially('Breast')
        self.assertEqual(self.page.locator('#eventSearch').input_value(),'Breast')
        self.assertEqual(self.page.locator('tr[data-id]').count(),2)
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'eventSearch')
        self.page.locator('#eventSearch').press('ControlOrMeta+A')
        self.page.locator('#eventSearch').press_sequentially('zzzzz')
        self.assertIn('No records match',self.page.locator('tbody').inner_text())
        self.render('partners')
        self.page.locator('#partnerSearch').press_sequentially('Demo Partner 02')
        self.assertEqual(self.page.locator('#partnerSearch').input_value(),'Demo Partner 02')
        self.assertEqual(self.page.locator('tr[data-id]').count(),1)

    def test_partner_selection_bilingual_search_and_preservation(self):
        self.login(lang='ar')
        self.page.locator('#quickEvent').click()
        self.assertEqual(self.page.locator('.partner-option').count(),21)
        self.page.locator('#linkedPartnerSearch').fill('Demo Partner 02')
        self.page.locator('[data-partner-check="2"]').check()
        self.page.locator('#linkedPartnerSearch').fill('جهة تجريبية 06')
        self.page.locator('[data-partner-check="6"]').check()
        self.page.locator('#linkedPartnerSearch').fill('not-a-partner')
        self.assertTrue(self.page.locator('#partnerNoResults').is_visible())
        self.page.locator('#linkedPartnerSearch').fill('')
        self.assertEqual(self.page.locator('[data-partner-check]:checked').count(),2)
        self.assertIn('2',self.page.locator('#selectedCount').inner_text())
        self.assertLessEqual(self.page.locator('[data-partner-check]').first.evaluate('(e)=>e.getBoundingClientRect().height'),20)
        self.page.locator('#ee').fill('Official event name')
        self.page.locator('#ed').fill('2026-11-20')
        self.page.locator('#saveEvent').click()
        self.page.reload()
        self.assertEqual(self.page.evaluate('state.events.at(-1).partners'),[2,6])
        self.assertEqual(self.page.evaluate('state.partners.length'),21)

    def test_event_validation_persistence_and_confirmed_deletion(self):
        self.login()
        self.page.locator('#quickEvent').click()
        self.page.locator('#saveEvent').click()
        self.assertTrue(self.page.locator('#formErrors').is_visible())
        self.page.locator('#ee').fill('Regression event')
        self.page.locator('#ed').fill('2026-12-30')
        self.page.locator('#ep').fill('101')
        self.page.locator('#saveEvent').click()
        self.assertEqual(self.page.evaluate('state.events.length'),10)
        self.page.locator('#ep').fill('75')
        self.page.locator('#saveEvent').click()
        self.assertEqual(self.page.evaluate('state.events.length'),11)
        self.page.reload()
        event_id=self.page.evaluate('state.events.at(-1).id')
        self.page.evaluate('(id)=>eventModal(id)',event_id)
        self.page.once('dialog',lambda d:d.dismiss())
        self.page.locator('#deleteEvent').click()
        self.assertEqual(self.page.evaluate('state.events.length'),11)
        self.page.once('dialog',lambda d:d.accept())
        self.page.locator('#deleteEvent').click()
        self.assertEqual(self.page.evaluate('state.events.length'),10)

    def test_request_conversion_is_idempotent_and_link_survives_reload(self):
        self.login()
        self.page.evaluate('requestModal("ER-2026-012")')
        self.page.locator('#convertReq').click()
        self.assertEqual(self.page.evaluate('state.events.length'),11)
        self.page.reload()
        self.page.evaluate('requestModal("ER-2026-012")')
        self.assertEqual(self.page.locator('#convertReq').inner_text(),'Open linked event')
        self.page.locator('#convertReq').click()
        self.assertEqual(self.page.evaluate('state.events.length'),11)
        self.assertEqual(self.page.locator('#ee').input_value(),'Alumni Networking Evening')

    def test_roles_fail_closed_and_viewer_can_read_events(self):
        for role in ['Viewer','unknown','']:
            self.login(role)
            self.assertFalse(self.page.evaluate('canEdit()'))
            self.assertEqual(self.page.locator('.nav [data-page="access"]').count(),0)
            self.page.evaluate('eventModal(103)')
            self.assertTrue(self.page.locator('#modal').is_visible())
            self.assertTrue(self.page.locator('#ee').is_disabled())
            self.assertEqual(self.page.locator('#saveEvent,#deleteEvent').count(),0)
            self.page.keyboard.press('Escape')
            self.page.evaluate('eventModal()')
            self.assertFalse(self.page.locator('#modal').is_visible())
        self.login('EMU Staff')
        self.assertTrue(self.page.evaluate('canEdit()'))
        self.assertEqual(self.page.locator('.nav [data-page="access"]').count(),0)
        self.page.locator('#quickEvent').click()
        self.page.locator('#ee').fill('Permission revoked')
        self.page.locator('#ed').fill('2026-10-22')
        self.page.evaluate('sessionStorage.setItem("emuRole","Viewer")')
        self.page.locator('#saveEvent').click()
        self.assertEqual(self.page.evaluate('state.events.length'),10)

    def test_dialog_focus_escape_and_trap(self):
        self.login()
        self.page.locator('#quickEvent').click()
        self.assertTrue(self.page.locator('#app').evaluate('(e)=>e.inert'))
        self.page.locator('#saveEvent').focus()
        self.page.keyboard.press('Tab')
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'closeModal')
        self.page.keyboard.press('Shift+Tab')
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'saveEvent')
        self.page.keyboard.press('Escape')
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'quickEvent')
        self.assertFalse(self.page.locator('#app').evaluate('(e)=>e.inert'))

    def test_mobile_navigation_both_directions(self):
        self.login()
        self.page.set_viewport_size({'width':390,'height':844})
        for lang in ['ar','en']:
            self.page.evaluate('(l)=>{lang=l;init()}',lang)
            self.page.locator('#menuBtn').click()
            self.assertEqual(self.page.locator('#menuBtn').get_attribute('aria-expanded'),'true')
            self.assertFalse(self.page.locator('#side').evaluate('(e)=>e.inert'))
            self.page.keyboard.press('Escape')
            self.assertEqual(self.page.evaluate('document.activeElement.id'),'menuBtn')
            self.page.locator('#menuBtn').click()
            self.page.locator('.nav [data-page="partners"]').click()
            self.assertEqual(self.page.locator('#partnerSearch').count(),1)
            self.assertTrue(self.page.locator('#side').evaluate('(e)=>e.inert'))

    def test_calendar_dynamic_dates_year_navigation_and_both_campuses(self):
        self.login()
        self.page.clock.install(time=__import__('datetime').datetime(2026,12,31,12,tzinfo=__import__('datetime').timezone.utc))
        self.page.reload()
        self.assertEqual(self.page.evaluate('todayISO()'),'2026-12-31')
        self.render('calendar')
        self.assertEqual(self.page.locator('.day.today>b').inner_text(),'31')
        self.page.locator('[data-month="1"]').click()
        self.assertEqual(self.page.evaluate('[calendarYear,calendarMonth]'),[2027,0])
        self.assertIn('Annual Career Fair',self.page.locator('.calendar').inner_text())
        self.page.locator('[data-month="-1"]').click()
        self.assertEqual(self.page.evaluate('[calendarYear,calendarMonth]'),[2026,11])
        self.render('events')
        self.page.locator('#eventCampus').select_option('Corniche')
        self.assertTrue(self.page.locator('[data-open-event="110"]').is_visible())
        self.page.locator('#eventCampus').select_option('North Obhur')
        self.assertTrue(self.page.locator('[data-open-event="110"]').is_visible())

    def test_kpi_navigation_and_filters(self):
        self.login()
        self.page.locator('[data-kpi="approvals"]').click()
        self.assertTrue(self.page.locator('[data-task-tab="approvals"]').get_attribute('aria-pressed')=='true')
        self.assertEqual(self.page.locator('[data-approval]').count(),3)
        self.page.locator('[data-kpi="done"]').click()
        self.assertEqual(self.page.locator('[data-task]').count(),2)
        self.render('partners')
        self.page.locator('[data-kpi="pactive"]').click()
        self.assertEqual(self.page.locator('#partnerStatus').input_value(),'Active')
        self.assertEqual(self.page.locator('tr[data-id]').count(),8)
        self.render('dashboard')
        self.page.locator('[data-kpi="tbd"]').click()
        self.assertEqual(self.page.locator('tr[data-id]').count(),1)
        self.render('reports')
        self.page.locator('[data-kpi="r2"]').click()
        self.assertEqual(self.page.locator('#eventStatus').input_value(),'Confirmed')

    def test_legacy_forms_validation_and_workflows(self):
        self.login()
        self.page.evaluate('taskModal()')
        self.page.locator('#tsv').click()
        self.assertEqual(self.page.evaluate('state.tasks.length'),7)
        self.page.locator('#ta').fill('مهمة اختبار')
        self.page.locator('#tdu').fill('2026-10-20')
        self.page.locator('#tsv').click()
        self.assertEqual(self.page.evaluate('state.tasks.length'),8)
        self.assertTrue(self.page.evaluate('state.events[0].tasks.includes(state.tasks.at(-1).id)'))
        self.page.evaluate('partnerModal()')
        self.page.locator('#pn').fill('Test partner')
        self.page.locator('#pe').fill('invalid-email')
        self.page.locator('#psave').click()
        self.assertEqual(self.page.evaluate('state.partners.length'),21)
        self.page.locator('#pe').fill('test@example.com')
        self.page.locator('#psave').click()
        self.assertEqual(self.page.evaluate('state.partners.length'),22)
        self.page.evaluate('followModal(1)')
        self.page.locator('#fn').fill('Confirmed contact')
        self.page.locator('#fsav').click()
        self.assertEqual(self.page.evaluate('state.partners.find(p=>p.id===1).history.length'),1)
        self.page.keyboard.press('Escape')
        self.page.evaluate('approvalModal(201)')
        self.page.locator('#as').select_option('Approved')
        self.page.locator('#asv').click()
        self.assertEqual(self.page.evaluate('state.approvals[0].status'),'Approved')

    def test_corrupted_storage_recovery_preserves_original(self):
        for original in ['{broken', '{"events":[]}']:
            self.page.evaluate('(raw)=>localStorage.setItem("emuV5",raw)',original)
            self.page.reload()
            self.assertTrue(self.page.locator('#storageNotice').is_visible())
            self.assertEqual(self.page.evaluate('localStorage.getItem("emuV5")'),original)
            self.assertTrue(self.page.locator('#loginForm').is_visible())
            self.assertEqual(self.page.evaluate('state.partners.length'),21)
        self.page.once('dialog',lambda d:d.accept())
        self.page.locator('#resetStorage').click()
        self.assertFalse(self.page.locator('#storageNotice').is_visible())
        self.assertEqual(self.page.evaluate('JSON.parse(localStorage.getItem("emuV5")).partners.length'),21)

    def test_bilingual_values_fallback_official_names_and_csv(self):
        self.login(lang='ar')
        for action in ['eventModal(103)','taskModal(1)','partnerModal(1)','followModal(1)']:
            self.page.evaluate(action)
            self.assertEqual(self.page.locator('#modal option').evaluate_all('(els)=>els.filter(o=>["Pending","Done","High","Corniche","Active","Call"].includes(o.textContent)).length'),0)
            self.page.keyboard.press('Escape')
        self.page.evaluate('state.tasks[0].titleAr="";state.events[0].orgAr=""')
        self.assertEqual(self.page.evaluate('translated(state.tasks[0],"title")'),'Final venue check')
        self.assertEqual(self.page.evaluate('orgName(state.events[0])'),'Training Center')
        self.assertEqual(self.page.evaluate('eventName(state.events[0])'),'Executive Book Club for University Leaders')
        self.page.evaluate('state.partners[0].phone="+DEMO-FORMULA"')
        self.render('partners')
        with self.page.expect_download() as result:
            self.page.locator('#exportPartners').click()
        csv=Path(result.value.path()).read_text(encoding='utf-8-sig')
        self.assertIn('الجهة',csv)
        self.assertIn('Demo Partner 01',csv)
        self.assertIn("'+DEMO-FORMULA",csv)

    def test_nested_entry_point(self):
        self.page.goto(self.url+'UBT_EMU_V10_Roles_Branding/')
        self.assertTrue(self.page.locator('#loginForm').is_visible())
        self.assertTrue(self.page.locator('.brand-row img').evaluate_all('(els)=>els.every(e=>e.complete&&e.naturalWidth>0)'))

    def test_chart_drilldown_and_clear(self):
        self.login()
        self.render('reports')
        self.page.locator('[data-report-month="2026-11"]').click()
        self.assertEqual(self.page.locator('tr[data-id]').count(),2)
        self.page.locator('#clearEventFilters').click()
        self.assertEqual(self.page.locator('tr[data-id]').count(),10)

    def test_storage_quota_failure_is_reported(self):
        self.login()
        self.page.evaluate('()=>{Storage.prototype.setItem=function(){throw new DOMException("Quota exceeded","QuotaExceededError")}}')
        self.page.locator('#quickEvent').click()
        self.page.locator('#ee').fill('Temporary record')
        self.page.locator('#ed').fill('2026-11-20')
        self.page.locator('#saveEvent').click()
        self.assertTrue(self.page.locator('#storageNotice').is_visible())
        self.assertIn('temporary',self.page.locator('#toast').inner_text())

    def test_stale_tab_cannot_overwrite_newer_data(self):
        self.login()
        self.page.evaluate('localStorage.setItem("emuV5",JSON.stringify(state))')
        self.page.reload()
        second=self.context.new_page()
        second.goto(self.url)
        second.evaluate('sessionStorage.setItem("emuLogin","1");sessionStorage.setItem("emuRole","EMU Admin");init()')
        second.evaluate('requestModal("ER-2026-012")')
        self.page.evaluate('requestModal("ER-2026-012")')
        self.page.locator('#convertReq').click()
        second.locator('#convertReq').click()
        self.assertTrue(second.locator('#storageNotice').is_visible())
        self.assertEqual(self.page.evaluate('JSON.parse(localStorage.getItem("emuV5")).events.length'),11)
        second.close()

    def test_approved_logo_integrity_layout_and_print(self):
        import hashlib
        expected={'EMU Logo BLUE.png':'f317c59a09b92bb644c1287cea8b118dc1c2e5885eb39d809c15334a71c36f89','EMU Logo.png':'715a1c9ddd7269f3dca0849136cc6416ebeaec0db021800b40db339ff11a4e61'}
        for name,digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT/'assets'/'branding'/name).read_bytes()).hexdigest(),digest)
        self.assertEqual(self.page.locator('.login-card .emu-logo--navy').count(),1)
        self.login()
        for lang in ['ar','en']:
            self.page.evaluate('(l)=>{lang=l;init()}',lang)
            for width in WIDTHS:
                self.page.set_viewport_size({'width':width,'height':1000})
                self.render('dashboard')
                self.page.locator('.header-emu-brand .emu-logo').evaluate('(e)=>e.decode()')
                self.page.locator('.hero .emu-logo').evaluate('(e)=>e.decode()')
                self.assertEqual(self.page.locator('.hero .emu-logo--white').count(),1)
                self.assertEqual(self.page.locator('.sidebar .emu-logo--white').count(),1)
                self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth-innerWidth'),1)
                for logo in self.page.locator('.emu-logo:visible').all():
                    data=logo.evaluate('(e)=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return {ratio:r.width/r.height,filter:s.filter,fit:s.objectFit,width:e.naturalWidth,height:e.naturalHeight}}')
                    self.assertEqual((data['width'],data['height']),(2249,1140))
                    self.assertAlmostEqual(data['ratio'],2249/1140,places=2)
                    self.assertEqual(data['filter'],'none')
                    self.assertEqual(data['fit'],'contain')
                if width<=780:
                    self.page.locator('#menuBtn').click()
                    self.assertTrue(self.page.locator('.sidebar .emu-logo--white').is_visible())
                    self.page.keyboard.press('Escape')
            self.render('reports')
            self.assertTrue(self.page.locator('.report-branding .emu-logo--navy').is_visible())
            self.page.emulate_media(media='print')
            self.assertTrue(self.page.locator('.print-branding .emu-logo--navy').is_visible())
            self.assertTrue(self.page.locator('.print-branding img[alt="UBT"]').is_visible())
            self.assertEqual(self.page.locator('.emu-logo--white:visible').count(),0)
            self.page.emulate_media(media='screen')
        self.page.goto(self.url+'UBT_EMU_V10_Roles_Branding/')
        self.assertTrue(self.page.locator('.emu-logo--navy').first.evaluate('(e)=>e.decode().then(()=>e.naturalWidth===2249)'))

    def test_request_form_validation_creation_and_pending_conversion(self):
        self.login(lang='ar')
        self.page.evaluate('requestModal()')
        self.page.locator('#rqSave').click()
        self.assertTrue(self.page.locator('#formErrors').is_visible())
        self.assertEqual(self.page.evaluate('state.requests.length'),3)
        request_id=self.page.locator('#rid').input_value()
        self.page.locator('#re').fill('ملتقى الجامعة التجريبي')
        self.page.locator('#rr').fill('وحدة إدارة الفعاليات')
        self.page.locator('#rd').fill('2026-11-14')
        self.page.locator('#rqSave').click()
        self.assertEqual(self.page.evaluate('state.requests.length'),4)
        self.page.evaluate('(id)=>requestModal(id)',request_id)
        self.assertTrue(self.page.locator('#rid').evaluate('(e)=>e.readOnly'))
        self.page.locator('#convertReq').click()
        self.assertEqual(self.page.evaluate('state.events.length'),10)
        self.assertTrue(self.page.locator('#formErrors').is_visible())
        self.page.locator('#rs').select_option('Approved')
        self.page.locator('#convertReq').click()
        self.assertEqual(self.page.evaluate('state.events.at(-1).titleEn'),'ملتقى الجامعة التجريبي')
        self.assertEqual(self.page.evaluate('state.events.at(-1).sourceRequestId'),request_id)
        self.page.reload()
        self.page.evaluate('(id)=>requestModal(id)',request_id)
        self.page.locator('#convertReq').click()
        self.assertEqual(self.page.evaluate('state.events.length'),11)

    def test_all_nine_navigation_buttons_in_both_languages(self):
        self.login()
        for language in ['ar','en']:
            self.page.evaluate('(l)=>{lang=l;init()}',language)
            for target in PAGES:
                self.page.locator(f'.nav [data-page="{target}"]').click()
                self.assertEqual(self.page.locator('.nav [aria-current="page"]').get_attribute('data-page'),target)
                self.assertTrue(self.page.locator('#content h1').inner_text())
                self.assertEqual(self.page.locator('html').get_attribute('dir'),'rtl' if language=='ar' else 'ltr')

    def test_independent_partner_statuses_contact_person_and_notes(self):
        self.login()
        self.page.evaluate('partnerModal(1)')
        self.page.locator('#pcontact').fill('Demo dedicated contact')
        previous=self.page.locator('#pprevious').input_value()
        self.page.locator('#ps').select_option('On Hold')
        self.page.locator('#psponsor').select_option('Negotiating')
        original=self.page.locator('#pnotes').input_value()
        self.page.locator('#pnotes').fill('New demo note')
        self.page.locator('#psave').click()
        partner=self.page.evaluate('state.partners.find(p=>p.id===1)')
        self.assertEqual(partner['relationshipStatus'],'On Hold')
        self.assertEqual(partner['sponsorshipStatus'],'Negotiating')
        self.assertEqual(partner['previousParticipation'],previous)
        self.assertEqual(partner['contactPerson'],'Demo dedicated contact')
        self.assertTrue(any(n['text']==original for n in partner['notesHistory']))
        self.assertNotIn('Demo dedicated contact',partner['notes'])
        self.page.evaluate('followModal(1)')
        self.page.locator('#fn').fill('A communication happened, not a status decision')
        self.page.locator('#fsav').click()
        self.assertEqual(self.page.evaluate('state.partners[0].relationshipStatus'),'On Hold')
        self.assertEqual(self.page.evaluate('state.partners[0].sponsorshipStatus'),'Negotiating')
        self.page.keyboard.press('Escape')
        self.render('partners')
        self.page.locator('#partnerStatus').select_option('On Hold')
        self.page.locator('#partnerSponsorStatus').select_option('Negotiating')
        self.assertEqual(self.page.locator('tr[data-id]').count(),1)
        self.page.reload()
        self.assertEqual(self.page.evaluate('state.partners[0].contactPerson'),'Demo dedicated contact')

    def test_legacy_partner_status_is_not_inferred(self):
        self.login()
        self.page.evaluate('state.partners[0].status="Active";delete state.partners[0].relationshipStatus;delete state.partners[0].sponsorshipStatus;partnerModal(1)')
        self.assertEqual(self.page.locator('#ps').input_value(),'')
        self.assertEqual(self.page.locator('#psponsor').input_value(),'')
        self.page.locator('#psave').click()
        self.assertIsNone(self.page.evaluate('state.partners[0].relationshipStatus'))
        self.assertIsNone(self.page.evaluate('state.partners[0].sponsorshipStatus'))

    def test_public_partner_fixtures_are_synthetic(self):
        partners=self.page.evaluate('SEED.partners')
        self.assertEqual(len(partners),21)
        self.assertEqual([p['id'] for p in partners],list(range(1,22)))
        for p in partners:
            self.assertIn('Demo Partner',p['name'])
            self.assertEqual(p['phone'],'')
            self.assertTrue(p['email'].endswith('@example.invalid'))
            self.assertIn('Demo Contact',p['contactPerson'])
            self.assertEqual(p['history'],[])
            self.assertNotIn('status',p)

    @unittest.skipUnless(os.environ.get('CAPTURE_SCREENSHOTS')=='1','Set CAPTURE_SCREENSHOTS=1 to capture review assets')
    def test_review_screenshots(self):
        out=ROOT/'screenshots';out.mkdir(exist_ok=True)
        self.login()
        def capture(name,full=False):
            self.page.screenshot(path=str(out/name),full_page=full,animations='disabled',caret='hide')
        for lang in ['ar','en']:
            self.page.evaluate('(l)=>{lang=l;init()}',lang)
            self.page.set_viewport_size({'width':1440,'height':1000})
            self.page.evaluate('sessionStorage.removeItem("emuLogin");init()');capture(f'login-{lang}.png')
            self.page.evaluate('sessionStorage.setItem("emuLogin","1");init()')
            self.render('reports');capture(f'reports-{lang}.png')
            self.page.emulate_media(media='print');capture(f'print-report-{lang}.png',True);self.page.emulate_media(media='screen')
            self.render('dashboard');capture(f'dashboard-{lang}.png',True)
            self.render('requests');self.page.evaluate('requestModal("ER-2026-014")');capture(f'event-request-{lang}.png');self.page.keyboard.press('Escape')
            self.page.evaluate('eventModal(103)');capture(f'event-form-{lang}.png')
            self.page.locator('.modal-card').evaluate('(e)=>{e.scrollTop=document.querySelector(".partner-selector").offsetTop-120}')
            capture(f'linked-partners-{lang}.png')
            self.page.keyboard.press('Escape');self.render('partners');capture(f'partners-{lang}.png',True)
            self.page.evaluate('partnerModal(1)');capture(f'partner-profile-{lang}.png');self.page.keyboard.press('Escape')
            for target in ['dashboard','events','calendar','partners']:
                self.page.set_viewport_size({'width':390,'height':844})
                self.page.evaluate('setNav(false)');self.render(target)
                self.page.evaluate('scrollTo(0,0)')
                capture(f'mobile-{target}-{lang}.png')
            self.render('dashboard');self.page.evaluate('eventModal(103)')
            self.page.locator('.modal-card').evaluate('(e)=>{e.scrollTop=document.querySelector(".partner-selector").offsetTop-100}')
            capture(f'mobile-event-form-{lang}.png');self.page.keyboard.press('Escape')
            self.page.evaluate('setNav(true)');capture(f'mobile-navigation-{lang}.png');self.page.evaluate('setNav(false)')
            self.render('requests');self.page.evaluate('requestModal("ER-2026-014")');capture(f'mobile-event-request-{lang}.png');self.page.keyboard.press('Escape')

if __name__=='__main__':
    unittest.main()
