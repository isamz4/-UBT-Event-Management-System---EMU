"""Published calendar and anonymous availability regressions, synthetic fixtures only."""
import unittest,os
from pathlib import Path
import test_v15 as base
class UniversityCalendar(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.V15Frontend.setUpClass.__func__(cls)
 @classmethod
 def tearDownClass(cls):base.V15Frontend.tearDownClass.__func__(cls)
 def setUp(self):base.V15Frontend.setUp(self)
 def tearDown(self):base.V15Frontend.tearDown(self)
 def login(self,role='EMU Director',language='en'):base.V15Frontend.login(self,role,language)
 def fixture(self):
  self.login();self.p.evaluate('''()=>{const e=E15.entity('events',15001);e.titleEn='Published university forum';e.titleAr='ملتقى الجامعة المنشور';e.date='2027-05-12';e.notes='CONFIDENTIAL_OPERATION';for(const a of state.approvals.filter(a=>a.eventId===e.id&&a.dept==='Marketing'))E15.approval(a.id,'Approved','Synthetic approval');E15.publication.request(e.id);E15.publication.review(e.id,'Approved','Public approval',{descriptionAr:'وصف عام معتمد',descriptionEn:'Approved public description',registrationLink:'https://example.invalid/register',image:'/assets/branding/EMU%20Logo%20BLUE.png'});const hidden=structuredClone(e);hidden.id=990001;hidden.titleEn='HIDDEN_EVENT_SECRET';hidden.published=false;hidden.calendarPublication={status:'Pending',history:[]};state.events.push(hidden);state.requests.push({id:990002,titleEn:'OTHER_REQUEST_SECRET',titleAr:'طلب آخر خاص',ownerEmail:'other@example.invalid',date:'2027-05-12',workflowStatus:'Submitted',details:{date:'2027-05-12',startTime:'14:00',endTime:'16:00',setupTime:'13:00',breakdownTime:'17:00',campus:'Corniche',venues:[{venueId:'1'}]}});E15.commit()}''')
 def query(self,**kwargs):return {'venueId':'1','campus':'Corniche','date':'2027-05-12','startTime':'14:30','endTime':'15:30','setupTime':'14:00','breakdownTime':'16:00',**kwargs}
 def test_all_six_roles_published_only_and_safe_details_exports(self):
  self.fixture()
  for role in self.p.evaluate('E15.roles'):
   self.login(role);self.p.evaluate('E15.filter.calendar={year:"2027",mode:"list"};render("calendar")');text=self.p.locator('#content').inner_text();self.assertIn('Published university forum',text,role);self.assertNotIn('HIDDEN_EVENT_SECRET',text);self.assertNotIn('OTHER_REQUEST_SECRET',text);self.assertNotIn('CONFIDENTIAL_OPERATION',text)
   self.p.locator('[data-public-detail="15001"]').first.click();self.assertIn('Approved public description',self.p.locator('#modalBody').inner_text());self.assertNotIn('CONFIDENTIAL_OPERATION',self.p.locator('#modalBody').inner_text());self.p.keyboard.press('Escape')
   rows=self.p.evaluate('E15.publishedEvents()');self.assertEqual(len(rows),1);self.assertFalse(set(rows[0])&{'notes','budget','partners','guests','calendarPublication','sourceRequestId','restricted'})
   self.assertTrue(self.p.evaluate('()=>{try{E15.publicDetails(990001);return false}catch{return true}}'))
 def test_requester_landing_actions_own_requests_and_other_roles_unchanged(self):
  self.fixture();self.p.evaluate('state.requests.push({id:990003,ownerEmail:"requester@example.invalid",reference:"EMU120527-030",titleEn:"My own request",date:"2027-05-12",workflowStatus:"Submitted",details:{}});E15.commit()')
  self.login('Authorized Event Requester');self.assertEqual(self.p.evaluate('page'),'calendar');text=self.p.locator('#content').inner_text();self.assertIn('Welcome to the University Events Calendar',text);self.assertIn('My own request',text);self.assertNotIn('OTHER_REQUEST_SECRET',text)
  self.p.locator('[data-v15="new-request"]').first.click();self.assertIn('1/14',self.p.locator('#modalTitle').inner_text());self.p.keyboard.press('Escape');self.p.locator('[data-availability]').first.click();self.assertTrue(self.p.locator('#availabilityForm').is_visible());self.p.keyboard.press('Escape')
  for role in ['EMU Director','EMU Staff','Supporting Department','Management Viewer','System Administrator']:
   self.p.evaluate('page="dashboard"');self.login(role);self.assertEqual(self.p.evaluate('page'),'dashboard')
 def test_real_login_and_role_preview_requester_landing(self):
  self.p.locator('#loginRole').select_option('Authorized Event Requester');self.p.locator('#signIn').click();self.assertEqual(self.p.evaluate('page'),'calendar');self.p.evaluate('E15.auth.switchIdentity(700002)');self.assertEqual(self.p.evaluate('page'),'dashboard');self.p.evaluate('E15.auth.switchIdentity(700005)');self.assertEqual(self.p.evaluate('page'),'calendar')
 def test_operational_visibility_staff_permission_and_restrictions(self):
  self.fixture();self.p.evaluate('render("operationalCalendar")');self.assertIn('HIDDEN_EVENT_SECRET',self.p.locator('#content').inner_text());self.assertIn('OTHER_REQUEST_SECRET',self.p.locator('#content').inner_text())
  self.login('EMU Staff');self.assertTrue(self.p.evaluate('E15.operationalCalendarAllowed()'));self.login();self.p.evaluate('E15.auth.staffPermission(700003,"reservation",false)');self.login('EMU Staff');self.assertFalse(self.p.evaluate('E15.operationalCalendarAllowed()'))
  for role in ['Authorized Event Requester','Supporting Department','Management Viewer','System Administrator']:
   self.login(role);self.p.evaluate('render("operationalCalendar")');self.assertNotIn('HIDDEN_EVENT_SECRET',self.p.locator('#content').inner_text());self.assertFalse(self.p.evaluate('E15.operationalCalendarAllowed()'));self.assertTrue(self.p.evaluate('()=>{try{E15.operationalCalendarPage();return false}catch{return true}}'))
 def test_anonymous_tentative_confirmed_and_nonconflicting_intervals(self):
  self.fixture();self.login('Authorized Event Requester');r=self.p.evaluate('(q)=>E15.checkAvailability(q)',self.query());self.assertEqual(r['status'],'TENTATIVELY RESERVED');self.assertEqual(set(r),{'status','blocks'});self.assertEqual(set(r['blocks'][0]),{'start','end','confirmed'});self.assertNotIn('SECRET',str(r))
  self.assertEqual(self.p.evaluate('(q)=>E15.checkAvailability(q).status',self.query(venueId='3')),'AVAILABLE')
  self.assertEqual(self.p.evaluate('(q)=>E15.checkAvailability(q).status',self.query(startTime='17:00',endTime='18:00',setupTime='17:00',breakdownTime='18:00')),'AVAILABLE')
  self.login();self.p.evaluate('state.reservations.push({id:990005,eventId:990001,venueId:"1",date:"2027-05-12",startTime:"14:00",endTime:"16:00",setupTime:"13:00",breakdownTime:"17:00",status:"Confirmed",note:"RESERVATION_SECRET"})');self.login('Authorized Event Requester');self.assertEqual(self.p.evaluate('(q)=>E15.checkAvailability(q).status',self.query(startTime='12:30',endTime='13:30',setupTime='12:00',breakdownTime='14:00')),'UNAVAILABLE')
  self.p.evaluate('E15.openAvailability()');self.fill_checker(self.query());self.assertIn('Unavailable',self.p.locator('#availabilityResult').inner_text());self.assertNotIn('SECRET',self.p.locator('#modalBody').inner_text());out=base.ROOT/'screenshots'/'v15-calendar';out.mkdir(exist_ok=True);self.p.screenshot(path=str(out/'confirmed-conflict.png'))
 def fill_checker(self,q):
  for k,v in q.items():
   field=self.p.locator('#av-'+k)
   if k in ['campus','venueId']:field.select_option(v)
   else:field.fill(v)
  self.p.locator('#av-endDate').fill(q.get('endDate',q['date']));self.p.locator('#availabilityCheck').click()
 def test_multiday_invalid_and_boundary_time_checks(self):
  self.fixture();self.p.evaluate('state.reservations.push({id:990005,eventId:990001,venueId:"1",date:"2027-05-14",endDate:"2027-05-16",startTime:"10:00",endTime:"12:00",setupTime:"09:00",breakdownTime:"13:00",status:"Confirmed"})')
  self.assertEqual(self.p.evaluate('(q)=>E15.checkAvailability(q).status',self.query(date='2027-05-15')),'UNAVAILABLE')
  for patch in [{'endTime':'bad'},{'endTime':'09:00'},{'date':'2027-02-30'},{'campus':'North Obhur'}]:self.assertTrue(self.p.evaluate('(q)=>{try{E15.checkAvailability(q);return false}catch{return true}}',self.query(**patch)))
 def test_filters_exports_week_navigation_and_readonly(self):
  import json
  self.fixture();self.login('Management Viewer');self.p.evaluate('E15.filter.calendar={year:"2027",mode:"list"};render("calendar")')
  self.p.locator('#moduleSearch').fill('no-public-match');self.assertEqual(self.p.locator('[data-public-detail]').count(),0);self.p.locator('#moduleSearch').fill('Published university forum');self.assertGreater(self.p.locator('[data-public-detail]').count(),0)
  self.p.locator('#annualVenue').select_option('3');self.assertEqual(self.p.locator('[data-public-detail]').count(),0);self.p.locator('#annualVenue').select_option('All');self.p.locator('#calendarFrom').fill('2028-01-01');self.assertEqual(self.p.locator('[data-public-detail]').count(),0);self.p.locator('#calendarFrom').fill('')
  with self.p.expect_download() as dl:self.p.locator('[data-v15="calendar-json"]').click()
  data=json.loads(Path(dl.value.path()).read_text());self.assertEqual(len(data),1);self.assertNotIn('SECRET',str(data));self.assertNotIn('CONFIDENTIAL',str(data))
  self.p.locator('#annualMode').select_option('week');self.p.locator('#calendarDate').fill('2027-05-12');self.p.locator('[data-public-week="1"]').click();self.assertEqual(self.p.locator('#calendarDate').input_value(),'2027-05-19');self.p.locator('#calendarDate').fill('');self.assertTrue(self.p.locator('#content').inner_text())
  self.assertEqual(self.p.locator('[data-v15="publication-review"],[data-v15="new-request"],#operationalCalendar').count(),0)
 def test_checker_does_not_create_booking_and_denied_roles(self):
  self.fixture();before=self.p.evaluate('state.reservations.length');self.p.evaluate('E15.openAvailability()');self.fill_checker(self.query());self.assertEqual(self.p.evaluate('state.reservations.length'),before);self.p.keyboard.press('Escape')
  for role in ['Supporting Department','Management Viewer','System Administrator']:
   self.login(role);self.assertTrue(self.p.evaluate('()=>{try{E15.checkAvailability({});return false}catch{return true}}'));self.assertTrue(self.p.evaluate('()=>{try{E15.openAvailability();return false}catch{return true}}'))
 def test_separate_publication_delegation_revocation_and_public_fields(self):
  self.login();eid=15001;self.assertEqual(self.p.evaluate('E15.publishedEvents().length'),0);self.p.evaluate('E15.publication.request(15001)');self.assertEqual(self.p.evaluate('E15.publishedEvents().length'),0)
  self.login('EMU Staff');self.assertTrue(self.p.evaluate('()=>{try{E15.publication.review(15001,"Approved","not delegated");return false}catch{return true}}'))
  self.login();self.p.evaluate('for(const a of state.approvals.filter(a=>a.eventId===15001&&a.dept==="Marketing"))E15.approval(a.id,"Approved","Ready");E15.auth.delegate(700003,"reviewPublication",true)');self.login('EMU Staff');self.p.evaluate('E15.publication.review(15001,"Approved","Delegated")');self.assertEqual(self.p.evaluate('E15.publishedEvents().length'),1)
  self.login();self.p.evaluate('E15.publication.withdraw(15001);E15.publication.request(15001);E15.auth.delegate(700003,"reviewPublication",false)');self.login('EMU Staff');self.assertTrue(self.p.evaluate('()=>{try{E15.publication.review(15001,"Approved","Revoked");return false}catch{return true}}'))
 def test_publication_expiration_and_unsafe_public_urls(self):
  self.login();self.p.evaluate('E15.publication.request(15001);E15.auth.delegate(700003,"reviewPublication",true);state.users.find(u=>u.id===700003).delegations.reviewPublication.expiresAt="2000-01-01";E15.commit()');self.login('EMU Staff');self.assertTrue(self.p.evaluate('()=>{try{E15.publication.review(15001,"Approved","Expired");return false}catch{return true}}'))
  self.login();self.assertTrue(self.p.evaluate('()=>{try{E15.publication.review(15001,"Approved","Bad URL",{image:"javascript:alert(1)"});return false}catch{return true}}'));self.assertFalse(self.p.evaluate('E15.entity("events",15001).published'))
 def test_wizard_availability_and_confirmed_submission_guard(self):
  self.fixture();self.login('Authorized Event Requester');self.p.evaluate('E15.openWizard();E15.handlers["wizard-demo"]();Object.assign(E15.wizard.details,{date:"2027-05-12",campus:"Corniche",startTime:"14:30",endTime:"15:30",setupTime:"14:00",breakdownTime:"16:00",venues:[{venueId:"1",seating:20,tables:0}]});E15.wizard.step=2;E15.drawWizard()');self.p.locator('#wizardAvailability').click();out=base.ROOT/'screenshots'/'v15-calendar';out.mkdir(exist_ok=True);self.p.screenshot(path=str(out/'wizard-availability.png'));self.assertIn('Tentatively Reserved',self.p.locator('#wizardAvailabilityResult').inner_text());self.p.locator('#wizardStandalone').click();self.assertTrue(self.p.locator('#availabilityForm').is_visible());self.p.locator('#modalBody button').filter(has_text='Return to request').click();self.assertTrue(self.p.locator('#wizardAvailability').is_visible())
  d=base.V15Frontend.details(self);d.update({'date':'2027-05-12','startTime':'14:30','endTime':'15:30','setupTime':'14:00','breakdownTime':'16:00','workshops':[]});self.p.evaluate('(d)=>E15.request.save(d,null,true)',d)
  self.login();self.p.evaluate('state.reservations.push({id:990006,eventId:990001,venueId:"1",date:"2027-05-12",startTime:"14:00",endTime:"16:00",status:"Confirmed"})');self.login('Authorized Event Requester');self.assertTrue(self.p.evaluate('(d)=>{try{E15.request.save(d,null,true);return false}catch(e){return e.message.includes("Confirmed venue conflict")}}',d))
 def test_bilingual_views_filters_responsive_and_screenshots(self):
  self.fixture();out=base.ROOT/'screenshots'/'v15-calendar';out.mkdir(exist_ok=True)
  for language in ['ar','en']:
   self.login('Authorized Event Requester',language)
   for width in [1440,1024,768,390,320]:
    self.p.set_viewport_size({'width':width,'height':1000})
    for mode in ['month','week','list']:
     self.p.evaluate('([l,m])=>{lang=l;E15.filter.calendar={year:"2027",mode:m,date:"2027-05-12"};calendarYear=2027;calendarMonth=4;render("calendar")}',[language,mode]);self.assertLessEqual(self.p.evaluate('document.documentElement.scrollWidth-innerWidth'),1);self.assertEqual(self.p.locator('html').get_attribute('dir'),'rtl' if language=='ar' else 'ltr')
   self.p.set_viewport_size({'width':1440,'height':1000});self.p.evaluate('E15.filter.calendar.mode="month";render("calendar")');self.p.screenshot(path=str(out/f'requester-landing-{language}.png'),full_page=True);self.p.set_viewport_size({'width':390,'height':844});self.p.screenshot(path=str(out/f'mobile-requester-{language}.png'));self.p.set_viewport_size({'width':1440,'height':1000})
   self.p.evaluate('E15.openAvailability()');self.fill_checker(self.query());self.p.screenshot(path=str(out/f'availability-{language}.png'));self.p.keyboard.press('Escape')
   self.login('Management Viewer',language);self.p.evaluate('render("calendar")');self.p.screenshot(path=str(out/f'published-calendar-{language}.png'),full_page=True)
  self.login();self.p.evaluate('render("operationalCalendar")');self.p.screenshot(path=str(out/'operational-calendar.png'),full_page=True)
