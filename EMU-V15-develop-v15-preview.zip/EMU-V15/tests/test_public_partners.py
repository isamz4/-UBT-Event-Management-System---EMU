"""Approved public catalog and clean-browser release checks; no private CSV fixture."""
import json,unittest
from pathlib import Path
import test_v15 as base
ROOT=Path(__file__).resolve().parents[1]
class PublicPartnerRelease(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.V15Frontend.setUpClass.__func__(cls)
 @classmethod
 def tearDownClass(cls):base.V15Frontend.tearDownClass.__func__(cls)
 def setUp(self):base.V15Frontend.setUp(self)
 def tearDown(self):base.V15Frontend.tearDown(self)
 def login(self):base.V15Frontend.login(self)
 def test_approved_catalog_auto_loads_without_private_fields(self):
  public=json.loads((ROOT/'assets/data/partners-public.json').read_text());self.assertEqual(len(public['records']),20)
  for row in public['records']:self.assertEqual(set(row),{'id','name','category','activity','previousParticipation'})
  self.login();self.p.evaluate('render("partners")');self.assertEqual(self.p.locator('tr[data-id]').count(),21)
  actual=self.p.evaluate('state.publicPartners');self.assertEqual(actual,public['records']);self.assertIn('Dfruit',self.p.locator('#content').inner_text());self.assertNotIn('Demo Partner',self.p.locator('#content').inner_text());self.assertNotIn('Demo Contact',self.p.locator('#content').inner_text())
  self.assertEqual(self.p.evaluate('state.partnerPrivateData'),{});self.assertIn('backend pending',self.p.locator('#content').inner_text());self.assertFalse(self.p.evaluate('SEED.partners.some(p=>["phone","email","contactPerson","notes","history","relationshipStatus","sponsorshipStatus"].some(k=>k in p))'))
 def test_public_search_category_participation_and_bilingual_names(self):
  self.login()
  for language in ['ar','en']:
   self.p.evaluate('(l)=>{lang=l;init();render("partners")}',language);self.p.locator('#partnerSearch').fill('Salus');self.assertEqual(self.p.locator('tr[data-id]').count(),1);self.p.locator('#partnerSearch').fill('');self.p.locator('#partnerCategory').select_option('أغذية صحية');self.assertEqual(self.p.locator('tr[data-id]').count(),3)
   self.p.locator('#partnerCategory').select_option('All');self.p.locator('#partnerParticipation').select_option('مؤكد سابقًا');self.assertEqual(self.p.locator('tr[data-id]').count(),8);self.p.locator('#partnerParticipation').select_option('All');self.assertIn('Andalusia Clinic’s',self.p.locator('#content').inner_text())
 def test_public_ids_event_links_and_reserved_id12_survive(self):
  self.login();links=self.p.evaluate('SEED.events.map(e=>({id:e.id,partners:e.partners}))');self.assertEqual(self.p.evaluate('state.events.filter(e=>e.id<15000).map(e=>({id:e.id,partners:e.partners}))'),links)
  self.assertEqual(self.p.evaluate('state.partners.find(p=>p.id===12).name'),'');self.assertFalse(self.p.evaluate('state.partners.find(p=>p.id===12).publicRecord'))
  self.p.evaluate('E15.handlers.workspace(103);E15.workspaceTab="guests";render("workspace")');self.assertIn('Salus',self.p.locator('#content').inner_text());self.assertIn('سنديان الخليج نبات',self.p.locator('#content').inner_text());self.assertNotIn('Demo Partner',self.p.locator('#content').inner_text())
 def test_public_network_asset_is_exact_allowlist(self):
  response=self.p.request.get(self.url+'assets/data/partners-public.json');self.assertEqual(response.status,200);public=response.json()
  for row in public['records']:self.assertFalse(set(row)&{'phone','email','contactPerson','notes','history','relationshipStatus','sponsorshipStatus'})
  self.assertEqual(public['reservedPartnerIds'],[12]);self.assertTrue(all(row['name'] for row in public['records']))
 def test_legacy_fictional_state_migrates_public_names_without_fake_contacts(self):
  self.login();self.p.evaluate('()=>{state.partnerCatalogVersion=0;delete state.privatePartnersLoaded;for(const p of state.partners){p.name="Demo Partner "+p.id;p.contactPerson="Demo Contact "+p.id;p.email="old@example.invalid";p.notes="Old fictional notes";p.history=[]}E15.commit()}');self.p.reload();self.p.evaluate('render("partners")');self.assertIn('Dfruit',self.p.locator('#content').inner_text());self.assertNotIn('Demo Contact',self.p.locator('#content').inner_text());self.assertEqual(self.p.evaluate('state.partnerPrivateData'),{})
if __name__=='__main__':unittest.main()
