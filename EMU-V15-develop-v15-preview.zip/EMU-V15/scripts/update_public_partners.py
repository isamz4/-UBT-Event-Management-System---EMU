"""Extract ONLY approved public CSV columns. Never copy the input into the checkout."""
import argparse,csv,hashlib,json,re,io
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
IDS=[*range(1,12),*range(13,22)]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--csv',required=True,type=Path);args=parser.parse_args()
 raw=args.csv.read_bytes()
 if hashlib.sha256(raw).hexdigest()!='4d9b54b5f50eb2dcd18f635d198ffadd2ad9a499a039ee6af4dc282580c7597e':raise SystemExit('Source differs from the approved CSV; obtain approval for a new mapping.')
 rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline='')))
 if len(rows)!=21 or any(len(row)!=8 for row in rows):raise SystemExit('Expected eight columns and twenty records.')
 public=[dict(id=id,name=row[0],category=row[1],activity=row[2],previousParticipation=row[6]) for id,row in zip(IDS,rows[1:])]
 if any(re.search(r'\S+@\S+\.\S+|\+\d[\d ()-]{7,}',str(v)) for row in public for v in row.values()):raise SystemExit('Contact-like value in public columns: review before publishing.')
 catalog={'schemaVersion':1,'source':'Approved public columns of the user-provided UTF-8 CSV','records':public,'reservedPartnerIds':[12]}
 (ROOT/'assets/data/partners-public.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
 path=ROOT/'data.js';seed=json.loads(path.read_text().split('const SEED=')[1].strip().removesuffix(';'))
 seed['partners']=[dict(id=p['id'],name=p['name'],catAr=p['category'],actAr=p['activity'],previousParticipation=p['previousParticipation'],publicRecord=True) for p in public]
 seed['partners'].append(dict(id=12,name='',catAr='',actAr='',previousParticipation='',publicRecord=False))
 seed['partners'].sort(key=lambda p:p['id'])
 path.write_text('// Approved public partner fields only; private contacts are never seeded.\nconst SEED='+json.dumps(seed,ensure_ascii=False,separators=(',',':'))+';\n')
 print(json.dumps({'approved_public_records':20,'reserved_private_ids':[12],'stable_ids':21,'private_columns_extracted':0}))
if __name__=='__main__':main()
