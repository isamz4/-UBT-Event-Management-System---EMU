# Approved official EMU logos

These files are byte-for-byte copies extracted from the supplied `EMU_Official_Logos.zip`. No image conversion, optimization, cropping, color changes, or resampling was performed. Both PNGs are 2249 × 1140, RGBA with original transparency.

| Original file       | Usage                                                                | SHA-256                                                            |
| ------------------- | -------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `EMU Logo BLUE.png` | White and light surfaces; login, header, reports, print              | `f317c59a09b92bb644c1287cea8b118dc1c2e5885eb39d809c15334a71c36f89` |
| `EMU Logo.png`      | Navy and dark surfaces; sidebar/mobile navigation and dashboard hero | `715a1c9ddd7269f3dca0849136cc6416ebeaec0db021800b40db339ff11a4e61` |

Use `emuLogo()` in `app.js` for reusable markup and `.emu-logo` styles for layout. Image dimensions use proportional scaling (`height:auto`, `object-fit:contain`), retaining the entire original canvas and transparent margins. Never apply filters, masks, cropping, or color replacements. Asset URLs resolve relative to `app.js`, so both entry points share the same originals.

The two obsolete `emu-logo.png` copies were removed. UBT logo files are unchanged.
